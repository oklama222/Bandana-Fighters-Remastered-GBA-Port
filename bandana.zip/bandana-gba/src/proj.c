#include "game.h"
proj_t g_proj[PROJ_MAX];
coin_t g_coins[COIN_MAX];
static fxp_t g_fxp[FXP_MAX];
void proj_clear(void) { u8 *z = (u8 *)g_proj; for (u32 i = 0; i < sizeof(g_proj); i++) z[i] = 0; }
void proj_clear_hostile(void) { for (int i = 0; i < PROJ_MAX; i++) if (!g_proj[i].friendly) g_proj[i].active = 0; }
proj_t *proj_alloc(void) {
    for (int i = 0; i < PROJ_MAX; i++) if (!g_proj[i].active) { u8 *z = (u8 *)&g_proj[i]; for (u32 k = 0; k < sizeof(proj_t); k++) z[k] = 0; g_proj[i].active = 1; return &g_proj[i]; }
    return 0;
}
void enemy_throw(const enemy_t *e, int dir) {
    proj_t *q = proj_alloc(); if (!q) return;
    q->w = 6; q->h = 4; q->vx = dir * 563; q->range = FX(400); q->friendly = 0;
    q->x = FX(dir > 0 ? FX_INT(e->b.x) + e->b.w : FX_INT(e->b.x) - 6); q->y = FX(FX_INT(e->b.y) + e->b.h * 4 / 10);
    q->dmg = g_enemy_defs[e->type].dmg;
}
static int target_dist(int ox, int tx, int tw) { return ABS(ox - (tx + tw / 2)); }
void proj_update(void) {
    for (int i = 0; i < PROJ_MAX; i++) {
        proj_t *p = &g_proj[i]; if (!p->active) continue;
        fx ox = p->x, oy = p->y;
        p->x += p->vx; p->y += p->vy;
        p->range -= MAX(ABS(p->vx), ABS(p->vy)) + MIN(ABS(p->vx), ABS(p->vy)) / 2;
        int cx = FX_INT(p->x) + p->w / 2, cy = FX_INT(p->y) + p->h / 2;
        if (p->range <= 0 || cx < -8 || cx > SCREEN_W + 8 || cy < -8 || cy > SCREEN_H || level_solid(cx >> 3, cy >> 3)) { p->active = 0; continue; }
        if (!p->friendly) {
            if (!g_player.invuln && !g_player.dead &&
                rect_hit(FX_INT(p->x), FX_INT(p->y), p->w, p->h, FX_INT(g_player.b.x), FX_INT(g_player.b.y), g_player.b.w, g_player.b.h)) {
                player_hurt(p->dmg, FX_INT(p->x)); p->active = 0;
            }
            continue;
        }
        int sx = FX_INT(MIN(ox, p->x)), sy = FX_INT(MIN(oy, p->y));                    /* test balaye : pas de traversee a haute vitesse */
        int sw = ABS(FX_INT(p->x) - FX_INT(ox)) + p->w, sh = ABS(FX_INT(p->y) - FX_INT(oy)) + p->h;
        int ox_px = FX_INT(ox);
        for (;;) {
            int best = -1, bd = 1 << 30;
            for (int k = 0; k < ENEMY_MAX; k++) {
                enemy_t *e = &g_enemies[k];
                if (!e->active || e->dead || (p->hitmask & (1 << k))) continue;
                if (!rect_hit(sx, sy, sw, sh, FX_INT(e->b.x), FX_INT(e->b.y), e->b.w, e->b.h)) continue;
                int d = target_dist(ox_px, FX_INT(e->b.x), e->b.w); if (d < bd) { bd = d; best = k; }
            }
            if (g_boss.active && !g_boss.dead && !(p->hitmask & 0x80) &&
                rect_hit(sx, sy, sw, sh, FX_INT(g_boss.b.x), FX_INT(g_boss.b.y), g_boss.b.w, g_boss.b.h)) {
                int d = target_dist(ox_px, FX_INT(g_boss.b.x), g_boss.b.w); if (d < bd) { bd = d; best = 7; }
            }
            if (best < 0) break;
            p->hitmask |= (u8)(1 << best);
            if (best == 7) boss_damage(p->dmg, p->lethal); else enemy_damage(&g_enemies[best], p->dmg, 0, p->lethal);
            if (!p->pierce) { p->active = 0; break; }
        }
    }
}
void proj_render(void) {
    for (int i = 0; i < PROJ_MAX; i++) {
        proj_t *p = &g_proj[i]; if (!p->active) continue;
        int cx = FX_INT(p->x) + p->w / 2, cy = FX_INT(p->y) + p->h / 2;
        spr_world(cx - 4, cy - 4, SPR_8, !p->friendly ? TILE_EBULLET : (p->pierce ? TILE_BIGDOT : TILE_BULLET), PAL_MISC, 0);
    }
}
/* ------------------------------ pieces ------------------------------ */
void coins_clear(void) { u8 *z = (u8 *)g_coins; for (u32 i = 0; i < sizeof(g_coins); i++) z[i] = 0; }
static void coin_collect(int value) {
    int v = (int)(((u32)value * g_bonus.coins + 128) >> 8); if (v < 1) v = 1;
    g_run.coins = MIN(g_run.coins + v, 99999); g_save.coins = MIN(g_save.coins + (u32)v, 999999u); sfx_play(SFX_COIN);
}
void coin_spawn(int x, int y, int value) {
    for (int i = 0; i < COIN_MAX; i++) if (!g_coins[i].active) {
        g_coins[i].active = 1; g_coins[i].value = (u8)value; g_coins[i].x = FX(x - 4); g_coins[i].y = FX(y - 8); g_coins[i].vy = -666; g_coins[i].t = 0;
        return;
    }
    coin_collect(value);                                     /* pool plein : credite directement */
}
void coins_update(void) {
    for (int i = 0; i < COIN_MAX; i++) {
        coin_t *c = &g_coins[i]; if (!c->active) continue;
        c->t++; c->vy += 38; c->y += c->vy;
        if (c->y > FX(GROUND_Y - 8)) { c->y = FX(GROUND_Y - 8); c->vy = 0; }
        if (!g_player.dead && rect_hit(FX_INT(c->x), FX_INT(c->y), 8, 8, FX_INT(g_player.b.x), FX_INT(g_player.b.y), g_player.b.w, g_player.b.h)) {
            c->active = 0; coin_collect(c->value);
        }
    }
}
void coins_render(void) {
    for (int i = 0; i < COIN_MAX; i++) if (g_coins[i].active) spr_world(FX_INT(g_coins[i].x), FX_INT(g_coins[i].y), SPR_8, TILE_COIN, PAL_MISC, 0);
}
/* ------------------------------ etincelles ------------------------------ */
void fxp_clear(void) { for (int i = 0; i < FXP_MAX; i++) g_fxp[i].life = 0; }
void fxp_spawn(int x, int y, int life) {
    int slot = 0, minl = 255;
    for (int i = 0; i < FXP_MAX; i++) { if (g_fxp[i].life == 0) { slot = i; break; } if (g_fxp[i].life < minl) { minl = g_fxp[i].life; slot = i; } }
    g_fxp[slot].x = (s16)x; g_fxp[slot].y = (s16)y; g_fxp[slot].life = (u8)life;
}
void fxp_update(void) { for (int i = 0; i < FXP_MAX; i++) if (g_fxp[i].life) g_fxp[i].life--; }
void fxp_render(void) { for (int i = 0; i < FXP_MAX; i++) if (g_fxp[i].life) spr_world(g_fxp[i].x - 4, g_fxp[i].y - 4, SPR_8, TILE_SPARK, PAL_MISC, 0); }
