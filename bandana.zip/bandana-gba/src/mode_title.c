#include "game.h"
static u32 frames;
static void enter(void) {
    cam_init(SCREEN_W, SCREEN_H);
    ui_text_center(UI_TXT, 2, "BANDANA", TXT_YELLOW);
    ui_text_center(UI_TXT, 5, "FIGHTERS", TXT_YELLOW);
    ui_text_center(UI_TXT, 8, "GBA EDITION", TXT_CYAN);
    ui_text(UI_TXT, 8, 11, "> VAGUES", TXT_WHITE);
    ui_text(UI_TXT, 8, 13, "  HISTOIRE", TXT_RED);
    ui_text(UI_TXT, 8, 15, "  BIENTOT", TXT_RED);
    ui_text(UI_TXT, 2, 17, "RECORD V", TXT_WHITE); ui_num(UI_TXT, 10, 17, g_save.best_wave, 2, TXT_WHITE);
    ui_text(UI_TXT, 16, 17, "PIECES", TXT_YELLOW); ui_num(UI_TXT, 22, 17, (int)MIN(g_save.coins, 99999u), 5, TXT_YELLOW);
}
static void update(void) {
    frames++;
    if (g_in.pressed & (KEY_START | KEY_A)) { rng_seed(frames * 2654435761u + 1); game_set_mode(&MODE_WAVES); }
}
static void render(void) { }
const game_mode_t MODE_TITLE = { enter, update, render, 0 };
