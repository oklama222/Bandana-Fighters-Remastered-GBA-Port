/* BANDANA FIGHTERS GBA - point d'entree. Pipeline : vsync -> flush OAM/scroll -> input -> logique -> rendu (shadow OAM). */
#include "game.h"
int main(void) {
    hw_init();
    art_init(); ui_init();
    save_load();
    rng_seed(0xBA2DA2A);
    game_set_mode(&MODE_TITLE);
    game_frame();                 /* construit la 1re image avant d'allumer l'ecran */
    hw_flush();
    hw_display(1);
    for (;;) {
        hw_vsync();
        hw_flush();
        input_update();
        game_frame();
    }
}
