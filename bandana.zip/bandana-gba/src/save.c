/* Sauvegarde SRAM a 2 emplacements alternes : une ecriture interrompue (coupure, reset) ne peut abimer
   que l'emplacement en cours d'ecriture ; l'autre reste valide. Chargement : le plus recent valide. */
#include "game.h"
save_t g_save;
#define SAVE_MAGIC 0x42464741u   /* 'BFGA' */
#define SLOT_SIZE 32
#define COINS_MAX 999999u
static int cur_slot;             /* emplacement contenant la derniere sauvegarde valide (-1 : aucun) */
static u16 checksum(const save_t *s) {
    const u8 *p = (const u8 *)s; u32 a = 0;
    for (u32 i = 8; i < sizeof(save_t); i++) a = a * 31 + p[i];       /* apres magic+version+sum */
    return (u16)(a ^ (a >> 16));
}
static int valid(const save_t *s) { return s->magic == SAVE_MAGIC && s->version == 1 && s->sum == checksum(s); }
static void defaults(void) {
    u8 *p = (u8 *)&g_save; for (u32 i = 0; i < sizeof(save_t); i++) p[i] = 0;
    g_save.magic = SAVE_MAGIC; g_save.version = 1; g_save.sel_char = CH_RYDER; g_save.owned_mask = 1; g_save.equipped = W_PISTOL;
    cur_slot = -1;
}
void save_load(void) {
    save_t s[2]; int ok[2];
    for (int i = 0; i < 2; i++) { hw_sram_read((u32)i * SLOT_SIZE, (u8 *)&s[i], sizeof(save_t)); ok[i] = valid(&s[i]); }
    if (!ok[0] && !ok[1]) { defaults(); return; }
    int pick = !ok[1] ? 0 : !ok[0] ? 1 : ((s16)(s[1].seq - s[0].seq) > 0 ? 1 : 0);
    g_save = s[pick]; cur_slot = pick;
    if (g_save.coins > COINS_MAX) g_save.coins = COINS_MAX;           /* assainissement */
    if (g_save.best_wave > 99) g_save.best_wave = 99;
    if (g_save.sel_char >= CH_COUNT) g_save.sel_char = CH_RYDER;
    if (g_save.equipped >= W_COUNT) g_save.equipped = W_PISTOL;
    g_save.owned_mask |= 1;
}
void save_write(void) {
    if (g_save.coins > COINS_MAX) g_save.coins = COINS_MAX;
    int target = cur_slot == 0 ? 1 : 0;
    g_save.seq++;
    g_save.sum = checksum(&g_save);
    hw_sram_write((u32)target * SLOT_SIZE, (const u8 *)&g_save, sizeof(save_t));
    cur_slot = target;
}
