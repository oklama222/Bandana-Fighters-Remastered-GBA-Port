#include "game.h"
static const game_mode_t *cur, *pending;
void game_set_mode(const game_mode_t *m) { pending = m; }
void game_frame(void) {
    if (pending) {
        if (cur && cur->leave) cur->leave();
        ui_clear(UI_TXT); ui_clear(UI_PNL);
        cur = pending; pending = 0;
        if (cur->enter) cur->enter();
    }
    if (cur) {
        if (cur->update) cur->update();
        spr_begin();
        if (cur->render) cur->render();
        spr_end();
        cam_update();
    }
}
