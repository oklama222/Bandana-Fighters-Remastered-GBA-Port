#include "game.h"
/* Police 3x5 agrandie x2 (6x10 dans une cellule de 8 px) : un caractere = 2 tuiles superposees.
   Chaque rangee du glyphe = 1 chiffre octal (3 bits). */
static const char GLYPHS[] = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ+-%/:!>.=<";
static const u16 GDATA[] = {
    00000, 075557, 026227, 071747, 071717, 055711, 074717, 074757, 071122, 075757, 075717,
    025755, 065656, 034443, 065556, 074647, 074644, 034553, 055755, 072227, 011152, 055655, 044447,
    057755, 065555, 025552, 065644, 025563, 065655, 034216, 072222, 055557, 055552, 055777, 055255, 055222, 071247,
    002720, 000700, 051245, 011244, 002020, 022202, 042124, 000002, 007070, 012421 };
#define FONT_BASE 16
#define BAR_BASE 112
#define TILE_PNL_FILL 9
static int glyph_of(char c) {
    if (c >= 'a' && c <= 'z') c = (char)(c - 32);
    for (int i = 0; GLYPHS[i]; i++) if (GLYPHS[i] == c) return i;
    return 0;
}
static void put_tile(u16 *t, int tile, const u8 px[8][8]) {
    for (int y = 0; y < 8; y++) for (int k = 0; k < 2; k++) {
        u16 v = 0; for (int i = 0; i < 4; i++) v |= (u16)((px[y][k*4+i] & 15) << (i*4));
        t[tile * 16 + y * 2 + k] = v;
    }
}
void ui_init(void) {
    u16 *t = hw_bg_tiles();
    for (int g = 0; g < ARRAY_LEN(GDATA); g++) {
        u8 top[8][8] = {{0}}, bot[8][8] = {{0}};
        for (int gy = 0; gy < 5; gy++) for (int gx = 0; gx < 3; gx++) {
            if (!((GDATA[g] >> ((4 - gy) * 3)) & 7 & (4 >> gx))) continue;
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) {
                int y = gy * 2 + dy, x = 1 + gx * 2 + dx;
                if (y < 8) top[y][x] = 1; else bot[y - 8][x] = 1;
            }
        }
        put_tile(t, FONT_BASE + g * 2, top); put_tile(t, FONT_BASE + g * 2 + 1, bot);
    }
    for (int n = 0; n <= 8; n++) {                        /* barre de PV : n pixels remplis sur 8 */
        u8 px[8][8] = {{0}};
        for (int y = 1; y < 7; y++) for (int x = 0; x < 8; x++) px[y][x] = (u8)(x < n ? 12 : 13);
        put_tile(t, BAR_BASE + n, px);
    }
    ui_clear(UI_TXT); ui_clear(UI_PNL);
}
static u16 *layer_map(int l) { return hw_bg_map(l == UI_TXT ? SB_BG1 : SB_BG2); }
void ui_clear(int l) { u16 *m = layer_map(l); for (int i = 0; i < 1024; i++) m[i] = 0; }
void ui_clear_rows(int l, int row, int n) { u16 *m = layer_map(l); for (int y = row; y < row + n && y < 32; y++) for (int x = 0; x < 32; x++) m[y * 32 + x] = 0; }
void ui_text(int l, int col, int row, const char *s, int pal) {
    u16 *m = layer_map(l);
    for (; *s && col < 30; s++, col++) {
        int g = glyph_of(*s);
        if (g == 0) { m[row * 32 + col] = 0; m[(row + 1) * 32 + col] = 0; continue; }
        m[row * 32 + col]       = (u16)((FONT_BASE + g * 2)     | (pal << 12));
        m[(row + 1) * 32 + col] = (u16)((FONT_BASE + g * 2 + 1) | (pal << 12));
    }
}
void ui_text_center(int l, int row, const char *s, int pal) {
    int n = 0; while (s[n]) n++;
    ui_text(l, MAX(0, (30 - n) / 2), row, s, pal);
}
void ui_num(int l, int col, int row, int v, int width, int pal) {
    char b[12]; int n = 0;
    if (v < 0) v = 0;
    do { b[n++] = (char)('0' + v % 10); v /= 10; } while (v && n < 10);
    char o[12]; int k = 0;
    for (int i = n; i < width; i++) o[k++] = ' ';
    while (n) o[k++] = b[--n];
    o[k] = 0;
    ui_text(l, col, row, o, pal);
}
void ui_bar(int col, int row, int cur, int max, int cells) {
    u16 *m = hw_bg_map(SB_BG1);
    int total = cells * 8, fill = max > 0 ? (cur * total) / max : 0;
    if (cur > 0 && fill == 0) fill = 1;
    fill = CLAMP(fill, 0, total);
    for (int i = 0; i < cells; i++) m[row * 32 + col + i] = (u16)(BAR_BASE + CLAMP(fill - i * 8, 0, 8));
}
void ui_panel(int col, int row, int w, int h) {
    u16 *m = hw_bg_map(SB_BG2);
    for (int y = row; y < row + h; y++) for (int x = col; x < col + w; x++) {
        int t = TILE_PNL_FILL;
        if (y == row) t = TILE_PNL_FILL + 1; else if (y == row + h - 1) t = TILE_PNL_FILL + 2;
        else if (x == col) t = TILE_PNL_FILL + 3; else if (x == col + w - 1) t = TILE_PNL_FILL + 4;
        m[y * 32 + x] = (u16)t;
    }
}
