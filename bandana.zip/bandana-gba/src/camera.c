#include "game.h"
camera_t g_cam;
void cam_init(int ww, int wh) { g_cam.x = g_cam.y = 0; g_cam.world_w = ww; g_cam.world_h = wh; g_cam.shake_t = g_cam.shake_amp = 0; }
void cam_follow(int tx) {                   /* zone morte de 40 px au centre */
    int want = tx - SCREEN_W / 2;
    if (want > g_cam.x + 20) g_cam.x = want - 20;
    else if (want < g_cam.x - 20) g_cam.x = want + 20;
    g_cam.x = CLAMP(g_cam.x, 0, MAX(0, g_cam.world_w - SCREEN_W));
}
void cam_shake(int frames, int amp) { g_cam.shake_t = frames; g_cam.shake_amp = amp; }
void cam_update(void) {
    g_cam.sx = g_cam.sy = 0;
    if (g_cam.shake_t > 0) {                /* meme decalage pour BG ET sprites : une seule camera */
        g_cam.shake_t--;
        g_cam.sx = (int)(g_cam.shake_t & 1) ? g_cam.shake_amp : -g_cam.shake_amp;
    }
    hw_set_scroll(0, g_cam.x + g_cam.sx, g_cam.y + g_cam.sy);
}
