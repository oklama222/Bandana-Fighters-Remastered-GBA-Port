#include "game.h"
player_t g_player;
void (*g_hook_player_down)(void);
const s16 g_dirv[8][2] = { {256,0},{181,181},{0,256},{-181,181},{-256,0},{-181,-181},{0,-256},{181,-181} };   /* E SE S SO O NO N NE */
static const s8 AIM_TAB[3][3] = { {5,6,7}, {4,-1,0}, {3,2,1} };
#define P_W 10
#define P_H 28
#define GRAVITY 75
#define JUMP_V (-1638)
#define BASE_SPEED 384
void player_init(int chr) {
    player_t *p = &g_player; u8 *z = (u8 *)p;
    for (u32 i = 0; i < sizeof(*p); i++) z[i] = 0;
    p->chr = (u8)chr;
    p->b.w = P_W; p->b.h = P_H; p->b.face = 1;
    p->b.x = FX(SCREEN_W / 2 - P_W / 2); p->b.y = FX(GROUND_Y - P_H);
    p->maxhp = p->hp = (s16)((100 * g_chars[chr].hp) >> 8);
    p->weapon = g_save.equipped < W_COUNT ? g_save.equipped : W_PISTOL;
    art_set_player_palette(chr);
}
int player_center_x(void) { return FX_INT(g_player.b.x) + P_W / 2; }
int player_center_y(void) { return FX_INT(g_player.b.y) + P_H / 2; }
void player_set_weapon(int w) { if (w >= 0 && w < W_COUNT) g_player.weapon = (u8)w; }
void player_heal(int a) { g_player.hp = (s16)MIN(g_player.maxhp, g_player.hp + a); }
void player_hurt(int dmg, int src_x) {
    player_t *p = &g_player;
    if (p->dead || g_chars[p->chr].invulnerable || p->invuln) return;
    dmg = MAX(1, (int)(((u32)dmg * g_bonus.defense + 128) >> 8));
    p->hp = (s16)(p->hp - dmg);
    p->invuln = BAL_INVULN_FRAMES; p->hurt_t = 18;
    sfx_play(SFX_HURT); cam_shake(6, 1);
    body_push(&p->b, player_center_x() < src_x ? -6 : 6);
    if (p->hp <= 0) { p->hp = 0; p->dead = 1; p->dead_t = 0; if (g_hook_player_down) g_hook_player_down(); }
}
void player_update(void) {
    player_t *p = &g_player; const char_def_t *c = &g_chars[p->chr];
    p->anim++;
    if (p->invuln) p->invuln--;
    if (p->hurt_t) p->hurt_t--;
    if (p->cd) p->cd--;
    art_update_player_palette(p->chr, p->anim);
    if (p->dead) { p->dead_t++; p->b.vx = 0; p->b.vy = MIN(p->b.vy + GRAVITY, 1792); body_move(&p->b); return; }
    u16 h = g_in.held;
    int dx = ((h & KEY_RIGHT) ? 1 : 0) - ((h & KEY_LEFT) ? 1 : 0);
    int dy = ((h & KEY_DOWN) ? 1 : 0) - ((h & KEY_UP) ? 1 : 0);
    int aiming = (h & KEY_R) != 0;
    if (g_in.pressed & KEY_R) p->aim = p->b.face > 0 ? 0 : 4;
    if (aiming) {                                   /* R + D-Pad = visee 8 directions, independante du deplacement */
        p->aim_free = 1;
        if (dx || dy) p->aim = (u8)AIM_TAB[dy + 1][dx + 1];
        if (g_dirv[p->aim][0] > 0) p->b.face = 1; else if (g_dirv[p->aim][0] < 0) p->b.face = -1;
    } else {
        p->aim_free = 0;
        if (dx) p->b.face = (s8)dx;
        p->aim = p->b.face > 0 ? 0 : 4;
    }
    int spd = (int)((((u32)BASE_SPEED * c->speed >> 8) * g_bonus.speed) >> 8);
    if (!aiming) p->b.vx = dx * spd;
    else if (p->b.ground) p->b.vx = 0;              /* au sol : on s'arrete pour viser ; en l'air : l'elan est conserve */
    if ((g_in.pressed & KEY_B) && p->b.ground) { p->b.vy = (JUMP_V * (int)c->jump) >> 8; sfx_play(SFX_JUMP); }
    p->b.vy = MIN(p->b.vy + GRAVITY, 1792);
    body_move(&p->b);
    if ((h & KEY_A) && p->cd == 0) weapon_fire(p);
}
void player_render(void) {
    player_t *p = &g_player; int x = FX_INT(p->b.x), y = FX_INT(p->b.y);
    if (p->invuln && !p->dead && (p->invuln & 3) < 2) return;      /* clignotement d'invincibilite */
    int frame = !p->b.ground ? 3 : (p->b.vx != 0 ? 1 + ((p->anim >> 3) & 1) : 0);
    int pal = p->hurt_t > 14 ? PAL_FLASH : PAL_PLAYER;
    spr_world(x - 3, y - 4, SPR_16x32, TILE_HUMAN(g_chars[p->chr].art, frame), pal, p->b.face < 0 ? SPR_HFLIP : 0);
    if (p->aim_free && !p->dead) {
        int mx = player_center_x() + (g_dirv[p->aim][0] * 20 >> 8), my = y + 13 + (g_dirv[p->aim][1] * 20 >> 8);
        spr_world(mx - 4, my - 4, SPR_8, TILE_CROSS, PAL_MISC, 0);
    }
}
