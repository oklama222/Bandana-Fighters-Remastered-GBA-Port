#include "game.h"
static int n_used;
static const u8 shape_of[4] = { 0, 0, 2, 0 };
static const u8 size_of[4]  = { 0, 1, 2, 2 };
static const u8 dim_w[4] = { 8, 16, 16, 32 };
static const u8 dim_h[4] = { 8, 16, 32, 32 };
void spr_begin(void) { n_used = 0; }
void spr_world(int wx, int wy, spr_size_t sz, int tile, int pal, int flags) {
    int sx = wx - g_cam.x - g_cam.sx, sy = wy - g_cam.y - g_cam.sy;
    if (sx <= -dim_w[sz] || sx >= SCREEN_W || sy <= -dim_h[sz] || sy >= SCREEN_H) return;   /* culling */
    if (n_used >= 128) return;
    u16 *o = hw_oam_shadow() + n_used * 4;
    o[0] = (u16)((sy & 0xFF) | (shape_of[sz] << 14));
    o[1] = (u16)((sx & 0x1FF) | ((flags & SPR_HFLIP) ? 0x1000 : 0) | (size_of[sz] << 14));
    o[2] = (u16)(tile | (pal << 12));          /* priorite 0 : au-dessus des fonds */
    n_used++;
}
void spr_end(void) {
    u16 *o = hw_oam_shadow();
    for (int i = n_used; i < 128; i++) { o[i*4] = 0x0200; o[i*4+1] = 0; o[i*4+2] = 0; }
}
int spr_count(void) { return n_used; }
