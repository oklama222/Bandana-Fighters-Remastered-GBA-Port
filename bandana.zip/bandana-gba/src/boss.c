#include "game.h"
boss_t g_boss;
void (*g_hook_boss_down)(void);
#define GRAVITY 75
#define BOSS_W 24
#define BOSS_H 30
enum { BS_CHASE, BS_TELEGRAPH, BS_SLAM };
void boss_spawn(int score) {
    boss_t *b = &g_boss; u8 *z = (u8 *)b; for (u32 i = 0; i < sizeof(*b); i++) z[i] = 0;
    int tier = MAX(1, score / 200);
    b->hp = b->maxhp = (s16)(260 + tier * 40);                       /* PV du jeu d'origine */
    b->active = 1; b->b.w = BOSS_W; b->b.h = BOSS_H;
    b->b.x = FX(g_player.b.face == 1 ? SCREEN_W - 46 : 22); b->b.y = FX(GROUND_Y - BOSS_H); b->b.face = -1;
    b->slam_cd = 255;
    sfx_play(SFX_BOSS);
}
void boss_damage(int dmg, int lethal) {
    boss_t *b = &g_boss; if (!b->active || b->dead) return;
    if (lethal && dmg < b->hp) dmg = b->hp;
    b->hp = (s16)(b->hp - dmg); b->flash = 5;
    fxp_spawn(FX_INT(b->b.x) + BOSS_W / 2, FX_INT(b->b.y) + 10, 6);
    if (b->hp > 0) { sfx_play(SFX_HIT); return; }
    b->dead = 1; b->dead_t = 45; b->hp = 0;
    g_run.score += 150;
    coin_spawn(FX_INT(b->b.x) + BOSS_W / 2, FX_INT(b->b.y) + 8, 100);
    cam_shake(14, 3); sfx_play(SFX_DEATH);
    if (g_hook_boss_down) g_hook_boss_down();
}
void boss_update(void) {
    boss_t *b = &g_boss; if (!b->active) return;
    b->anim++; if (b->flash) b->flash--; if (b->melee_cd) b->melee_cd--;
    if (b->dead) { if (--b->dead_t == 0) b->active = 0; return; }
    int bx = FX_INT(b->b.x), bcx = bx + BOSS_W / 2, cdx = player_center_x() - bcx, dist = ABS(cdx), dir = cdx >= 0 ? 1 : -1;
    b->b.face = (s8)dir; b->b.vx = 0;
    switch (b->state) {
    case BS_CHASE:
        if (b->timer) {                                                  /* annonce du coup de poing : 0,4 s */
            if (--b->timer == 0 && dist <= 45 && FX_INT(g_player.b.y) + g_player.b.h > FX_INT(b->b.y) + 4) player_hurt(16, bcx);
        } else if (dist > 35) b->b.vx = dir * 169;
        else if (b->melee_cd == 0) { b->melee_cd = 54; b->timer = 24; }
        if (b->slam_cd) b->slam_cd--;
        if (b->slam_cd == 0) { b->state = BS_TELEGRAPH; b->timer = 42; }
        break;
    case BS_TELEGRAPH:                                                   /* signal visuel avant le coup */
        if ((b->timer & 7) == 0) fxp_spawn(bcx + rng_range(30) - 15, GROUND_Y - 6, 8);
        if (--b->timer == 0) {
            b->state = BS_SLAM; b->timer = 9;
            if (g_player.b.ground && dist < 90) player_hurt(22, bcx);
            cam_shake(10, 2); sfx_play(SFX_BOSS);
            for (int k = -2; k <= 2; k++) fxp_spawn(bcx + k * 30, GROUND_Y - 6, 12);
        }
        break;
    default:
        if (--b->timer == 0) { b->state = BS_CHASE; b->slam_cd = 255; }
        break;
    }
    b->b.vy = MIN(b->b.vy + GRAVITY, 1792);
    body_move(&b->b);
    b->b.x = CLAMP(b->b.x, 0, FX(SCREEN_W - BOSS_W));
}
void boss_render(void) {
    boss_t *b = &g_boss; if (!b->active) return;
    if (b->dead && (b->dead_t & 2)) return;
    int pal = (b->flash || (b->state == BS_TELEGRAPH && (b->anim & 4))) ? PAL_FLASH : PAL_BOSS;
    int frame = (b->state != BS_CHASE) ? 1 : 0;
    spr_world(FX_INT(b->b.x) - 4, FX_INT(b->b.y) - 2, SPR_32, TILE_BOSS(frame), pal, b->b.face < 0 ? SPR_HFLIP : 0);
}
