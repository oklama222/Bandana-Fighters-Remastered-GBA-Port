/* Effets PSG (canal 1 carre + canal 4 bruit). Env : vol<<12 | dir<<11 | pas<<8 ; duty<<6 */
#include "game.h"
void sfx_play(int id) {
    switch (id) {
    case SFX_SHOOT: hw_snd_noise(0xA100, 0x0044); break;
    case SFX_HEAVY: hw_snd_noise(0xF200, 0x0053); break;
    case SFX_HIT:   hw_snd_tone(1700, 0x8100, 0x80); break;
    case SFX_DEATH: hw_snd_noise(0xC300, 0x0066); break;
    case SFX_COIN:  hw_snd_tone(1900, 0x7100, 0x40); break;
    case SFX_JUMP:  hw_snd_tone(1500, 0x6100, 0x80); break;
    case SFX_HURT:  hw_snd_tone(900,  0xD200, 0x80); break;
    case SFX_BONUS: hw_snd_tone(1950, 0xA200, 0x40); break;
    case SFX_BOSS:  hw_snd_tone(500,  0xF300, 0x80); break;
    case SFX_DOOR:  hw_snd_tone(1750, 0x9200, 0x40); break;
    }
}
