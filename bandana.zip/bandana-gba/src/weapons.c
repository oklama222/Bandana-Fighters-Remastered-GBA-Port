#include "game.h"
extern const s16 g_dirv[8][2];
void weapon_fire(player_t *p) {
    const weapon_def_t *w = &g_weapons[p->weapon]; const char_def_t *c = &g_chars[p->chr];
    int dmg = (int)(((((u32)w->dmg * 256 * c->dmg) >> 8) * g_bonus.dmg >> 8) + 128) >> 8;
    if (dmg < 1) dmg = 1;
    p->cd = (u8)MAX(4, (int)(((u32)w->cd * g_bonus.fire) >> 8));
    const s16 *d = g_dirv[p->aim];
    if (p->aim_free) { if (d[0] > 51) p->b.face = 1; else if (d[0] < -51) p->b.face = -1; }
    int px = FX_INT(p->b.x), py = FX_INT(p->b.y);
    if (w->melee) {                                         /* gant : zone devant le joueur, la visee haute etend vers le haut */
        int up = (d[1] < 0) ? 14 : 0, reach = w->range_px;
        int rx = p->b.face > 0 ? px + p->b.w : px - reach, ry = py - up, rh = p->b.h + up;
        for (int i = 0; i < ENEMY_MAX; i++) {
            enemy_t *e = &g_enemies[i];
            if (e->active && !e->dead && rect_hit(rx, ry, reach, rh, FX_INT(e->b.x), FX_INT(e->b.y), e->b.w, e->b.h))
                enemy_damage(e, dmg, p->b.face, c->lethal);
        }
        if (g_boss.active && !g_boss.dead && rect_hit(rx, ry, reach, rh, FX_INT(g_boss.b.x), FX_INT(g_boss.b.y), g_boss.b.w, g_boss.b.h))
            boss_damage(dmg, c->lethal);
        fxp_spawn(rx + reach / 2, py + 12, 6); sfx_play(SFX_HEAVY);
        return;
    }
    int mx = px + p->b.w / 2 + (d[0] * 18 >> 8), my = py + 13 + (d[1] * 18 >> 8);
    for (int i = 0; i < w->pellets; i++) {
        proj_t *q = proj_alloc(); if (!q) break;
        int vperp = 0;
        if (w->pellets > 1) vperp = ((w->speed * w->spread >> 8) * (2 * i - (w->pellets - 1))) / 2;
        else if (w->jitter) { int j = w->speed * w->jitter >> 8; vperp = rng_range(2 * j + 1) - j; }
        q->vx = ((d[0] * w->speed) >> 8) + ((-d[1] * vperp) >> 8);
        q->vy = ((d[1] * w->speed) >> 8) + ((d[0] * vperp) >> 8);
        q->w = w->pw; q->h = w->ph;
        q->x = FX(mx - q->w / 2); q->y = FX(my - q->h / 2);
        q->range = FX(w->range_px); q->friendly = 1; q->pierce = w->pierce; q->lethal = c->lethal; q->dmg = (s16)dmg; q->hitmask = 0;
    }
    fxp_spawn(mx, my, 3);
    sfx_play((p->weapon == W_SHOTGUN || p->weapon == W_RAILGUN) ? SFX_HEAVY : SFX_SHOOT);
}
