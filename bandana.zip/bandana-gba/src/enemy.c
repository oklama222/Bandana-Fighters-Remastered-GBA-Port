#include "game.h"
enemy_t g_enemies[ENEMY_MAX];
void (*g_hook_enemy_down)(void);
#define GRAVITY 75
void enemies_clear(void) { u8 *z = (u8 *)g_enemies; for (u32 i = 0; i < sizeof(g_enemies); i++) z[i] = 0; }
int enemies_alive(void) { int n = 0; for (int i = 0; i < ENEMY_MAX; i++) if (g_enemies[i].active && !g_enemies[i].dead) n++; return n; }
static int bats_alive(void) { int n = 0; for (int i = 0; i < ENEMY_MAX; i++) if (g_enemies[i].active && !g_enemies[i].dead && g_enemies[i].type == E_BAT) n++; return n; }
static int pick_type(void) {                                     /* 42 % voyou / 26 % fonceur / 16 % lanceur / 16 % chauve-souris */
    int r = rng_range(100);
    if (r < 42) return E_GRUNT;
    if (r < 68) return E_RUSHER;
    if (r < 84) return E_THROWER;
    if (g_run.score >= 10 && bats_alive() < BATS_ALIVE_MAX) return E_BAT;
    return E_GRUNT;
}
int enemies_spawn_random(void) {
    if (enemies_alive() >= ENEMY_ALIVE_MAX) return 0;
    enemy_t *e = 0;
    for (int i = 0; i < ENEMY_MAX; i++) if (!g_enemies[i].active) { e = &g_enemies[i]; break; }
    if (!e) return 0;
    int t = pick_type(); const enemy_def_t *d = &g_enemy_defs[t];
    u8 *z = (u8 *)e; for (u32 i = 0; i < sizeof(*e); i++) z[i] = 0;
    e->active = 1; e->type = (u8)t; e->b.w = d->w; e->b.h = d->h;
    e->hp = e->maxhp = (s16)(d->hp + (g_run.score / 120) * 2);        /* progression de PV du jeu d'origine */
    int left = rng_range(2);
    e->b.x = FX(left ? 6 : SCREEN_W - 6 - d->w); e->b.face = left ? 1 : -1;
    if (d->flying) {
        e->hover_y = (s16)(30 + rng_range(40)); e->b.y = FX(MAX(8, e->hover_y - 20));
        e->bphase = (u8)rng_range(256); e->atk_cd = 90;               /* rode avant sa premiere attaque */
    } else e->b.y = FX(GROUND_Y - d->h);
    return 1;
}
void enemy_damage(enemy_t *e, int dmg, int kdir, int lethal) {
    if (!e->active || e->dead) return;
    if (lethal && dmg < e->hp) dmg = e->hp;
    e->hp = (s16)(e->hp - dmg); e->flash = 5;
    int cx = FX_INT(e->b.x) + e->b.w / 2, cy = FX_INT(e->b.y) + e->b.h / 2;
    fxp_spawn(cx, cy, 6);
    if (kdir) body_push(&e->b, kdir * 16);
    if (e->hp > 0) { e->wind = 0; sfx_play(SFX_HIT); return; }   /* un tir qui touche interrompt l'annonce du coup */
    e->dead = 1; e->dead_t = 24; e->b.vx = 0; e->b.vy = g_enemy_defs[e->type].flying ? 100 : 0;
    g_run.score += g_enemy_defs[e->type].points;
    coin_spawn(cx, cy, 1);
    sfx_play(SFX_DEATH);
    if (g_hook_enemy_down) g_hook_enemy_down();
}
static void steer(enemy_t *e, int tx, int ty, int sp, int shift) {
    int cx = FX_INT(e->b.x) + e->b.w / 2, cy = FX_INT(e->b.y) + e->b.h / 2;
    int dx = tx - cx, dy = ty - cy, ax = ABS(dx), ay = ABS(dy);
    int d = MAX(ax, ay) + MIN(ax, ay) / 2; if (d == 0) d = 1;       /* norme approchee, sans racine */
    e->b.vx += (dx * sp / d - e->b.vx) >> shift;
    e->b.vy += (dy * sp / d - e->b.vy) >> shift;
}
static void bat_update(enemy_t *e) {
    const enemy_def_t *d = &g_enemy_defs[E_BAT];
    int pcx = player_center_x(), pcy = FX_INT(g_player.b.y) + 11;
    int cx = FX_INT(e->b.x) + e->b.w / 2, cy = FX_INT(e->b.y) + e->b.h / 2;
    e->phase16 = (u16)(e->phase16 + 190);
    if (e->btimer) e->btimer--;
    switch (e->bstate) {
    case 0: {                                                        /* rode au-dessus du joueur */
        int tx = pcx + (isin((e->phase16 >> 8) + e->bphase) * 72 >> 8);
        int ty = e->hover_y + (isin(((e->phase16 >> 8) * 5 >> 1)) * 10 >> 8);
        steer(e, tx, ty, d->speed, 4);
        if (e->atk_cd == 0 && ABS(pcx - cx) < 114 && !g_player.dead) { e->bstate = 1; e->btimer = 17; e->atk_anim = 17; }
    } break;
    case 1:                                                          /* se fige, ailes battantes */
        e->b.vx -= e->b.vx >> 3; e->b.vy -= e->b.vy >> 3;
        if (e->btimer == 0) { e->bstate = 2; e->btimer = 48; e->dive_x = (s16)pcx; e->dive_y = (s16)pcy; }
        break;
    case 2: {                                                        /* pique sur la position visee : esquivable */
        steer(e, e->dive_x, e->dive_y, d->speed * 26 / 10, 3);
        int ax = ABS(e->dive_x - cx), ay = ABS(e->dive_y - cy);
        if (MAX(ax, ay) < 10 || e->btimer == 0) { e->bstate = 3; e->btimer = 42; e->atk_cd = d->atk_cd; }
    } break;
    default: {                                                       /* remonte et s'ecarte */
        int tx = CLAMP(cx + (cx < pcx ? -72 : 72), 14, SCREEN_W - 14);
        steer(e, tx, e->hover_y - 24, d->speed * 125 / 100, 3);
        if (e->btimer == 0) e->bstate = 0;
    } break;
    }
    e->b.x += e->b.vx; e->b.y += e->b.vy;
    e->b.x = CLAMP(e->b.x, 0, FX(SCREEN_W - e->b.w));
    e->b.y = CLAMP(e->b.y, FX(6), FX(GROUND_Y - e->b.h - 4));
    if (e->b.vx > 4096 / 256 * 4) e->b.face = 1; else if (e->b.vx < -4096 / 256 * 4) e->b.face = -1;
    if (e->hit_cd) e->hit_cd--;
    if (!g_player.dead && e->hit_cd == 0 &&
        rect_hit(FX_INT(e->b.x), FX_INT(e->b.y), e->b.w, e->b.h, FX_INT(g_player.b.x), FX_INT(g_player.b.y), g_player.b.w, g_player.b.h)) {
        e->hit_cd = 42; player_hurt(d->dmg, cx);
        if (e->bstate == 2) { e->bstate = 3; e->btimer = 42; e->atk_cd = d->atk_cd; }
    }
}
void enemies_update(void) {
    for (int i = 0; i < ENEMY_MAX; i++) {
        enemy_t *e = &g_enemies[i]; if (!e->active) continue;
        const enemy_def_t *d = &g_enemy_defs[e->type];
        e->anim++; if (e->flash) e->flash--; if (e->atk_anim) e->atk_anim--; if (e->atk_cd) e->atk_cd--;
        if (e->dead) {
            if (d->flying) {                                          /* cadavre de chauve-souris : chute */
                e->b.vy = MIN(e->b.vy + GRAVITY, 1792); e->b.y += e->b.vy;
                if (e->b.y > FX(GROUND_Y - e->b.h)) e->b.y = FX(GROUND_Y - e->b.h);
            }
            if (--e->dead_t == 0) e->active = 0;
            continue;
        }
        if (d->flying) { bat_update(e); continue; }
        int ecx = FX_INT(e->b.x) + e->b.w / 2, cdx = player_center_x() - ecx, dist = ABS(cdx);
        int dir = cdx >= 0 ? 1 : -1;
        e->b.face = (s8)dir; e->b.vx = 0;
        if (d->ranged) {
            if (dist > d->atk_range * 6 / 10) e->b.vx = dir * (d->speed * BAL_ENEMY_SPEED_PCT / 100);
            if (dist <= d->atk_range && e->atk_cd == 0 && !g_player.dead) { e->atk_cd = d->atk_cd; e->atk_anim = 20; enemy_throw(e, dir); }
        } else if (e->wind) {                                        /* ANNONCE du coup : le joueur peut reculer ou sauter */
            e->b.vx = 0;
            if (--e->wind == 0 && !g_player.dead && dist <= d->atk_range + 8 &&
                FX_INT(g_player.b.y) + g_player.b.h > FX_INT(e->b.y) + 4) player_hurt(d->dmg, ecx);
        } else if (dist > d->atk_range) {
            int spd = d->speed * BAL_ENEMY_SPEED_PCT / 100;
            if (e->type == E_RUSHER && dist < 114) spd = spd * 155 / 100;   /* le fonceur accelere a l'approche */
            e->b.vx = dir * spd;
        } else if (e->atk_cd == 0) {
            e->atk_cd = d->atk_cd; e->wind = BAL_MELEE_WINDUP; e->atk_anim = BAL_MELEE_WINDUP;   /* annonce (pose d'attaque visible) */
        }
        e->b.vy = MIN(e->b.vy + GRAVITY, 1792);
        body_move(&e->b);
        for (int j = 0; j < ENEMY_MAX; j++) {                          /* legere separation entre ennemis au sol */
            enemy_t *o = &g_enemies[j];
            if (j == i || !o->active || o->dead || g_enemy_defs[o->type].flying) continue;
            int dx = FX_INT(e->b.x) - FX_INT(o->b.x);
            if (ABS(dx) < e->b.w * 7 / 10) e->b.x += (dx > 0 || (dx == 0 && i > j)) ? 26 : -26;
        }
        e->b.x = CLAMP(e->b.x, 0, FX(SCREEN_W - e->b.w));
    }
}
void enemies_render(void) {
    for (int i = 0; i < ENEMY_MAX; i++) {
        enemy_t *e = &g_enemies[i]; if (!e->active) continue;
        if (e->dead && (e->dead_t & 2)) continue;                     /* clignote puis disparait */
        const enemy_def_t *d = &g_enemy_defs[e->type];
        int x = FX_INT(e->b.x), y = FX_INT(e->b.y), pal = e->flash ? PAL_FLASH : d->pal, fl = e->b.face < 0 ? SPR_HFLIP : 0;
        if (d->flying) {
            spr_world(x - 1, y - 3, SPR_16, TILE_BAT(e->atk_anim ? 0 : ((e->anim >> 2) & 1)), pal, fl);
        } else {
            int frame = (e->dead || e->atk_anim) ? 3 : (e->b.vx ? 1 + ((e->anim >> 3) & 1) : 0);
            spr_world(x - 3, y + e->b.h - 32, SPR_16x32, TILE_HUMAN(d->art, frame), pal, fl);
        }
    }
}
