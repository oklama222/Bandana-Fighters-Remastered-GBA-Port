/* Implementation GBA reelle. Aucune bibliotheque : registres directs. NON TESTE sur ROM. */
#include "hw.h"
#define R16(a) (*(volatile u16 *)(a))
#define DISPCNT   R16(0x04000000)
#define VCOUNT    R16(0x04000006)
#define BGCNT(n)  R16(0x04000008 + 2*(n))
#define BGOFS_X(n) R16(0x04000010 + 4*(n))
#define BGOFS_Y(n) R16(0x04000012 + 4*(n))
#define KEYINPUT  R16(0x04000130)
#define SND1_L R16(0x04000060)
#define SND1_H R16(0x04000062)
#define SND1_X R16(0x04000064)
#define SND4_L R16(0x04000078)
#define SND4_H R16(0x0400007C)
#define SNDCNT_L R16(0x04000080)
#define SNDCNT_H R16(0x04000082)
#define SNDCNT_X R16(0x04000084)
#define OAM_MEM ((volatile u16 *)0x07000000)

static u16 oam_shadow[128 * 4];
static int scroll[4][2];

void hw_init(void) {
    DISPCNT = 0x0080;                                   /* forced blank pendant l'init */
    BGCNT(0) = 3 | (0 << 2) | (SB_BG0 << 8);            /* prio 3 */
    BGCNT(1) = 1 | (0 << 2) | (SB_BG1 << 8);            /* prio 1 */
    BGCNT(2) = 2 | (0 << 2) | (SB_BG2 << 8);            /* prio 2 */
    SNDCNT_X = 0x80; SNDCNT_L = 0xFF77; SNDCNT_H = 0x0002;  /* PSG on, volume max */
    for (int i = 0; i < 128; i++) { oam_shadow[i*4] = 0x0200; oam_shadow[i*4+1] = 0; oam_shadow[i*4+2] = 0; }
}
void hw_display(int on) {
    /* mode 0 | OBJ 1D | BG0 BG1 BG2 | OBJ */
    DISPCNT = on ? (0x0000 | 0x0040 | 0x0100 | 0x0200 | 0x0400 | 0x1000) : 0x0080;
}
void hw_vsync(void) { while (VCOUNT >= 160) {} while (VCOUNT < 160) {} }
void hw_flush(void) {
    for (int i = 0; i < 128 * 4; i++) OAM_MEM[i] = oam_shadow[i];
    for (int b = 0; b < 3; b++) { BGOFS_X(b) = (u16)scroll[b][0]; BGOFS_Y(b) = (u16)scroll[b][1]; }
}
u16 hw_keys(void) { return (u16)(~KEYINPUT & 0x03FF); }
u16 *hw_bg_tiles(void)  { return (u16 *)0x06000000; }
u16 *hw_bg_map(int sb)  { return (u16 *)(0x06000000 + sb * 0x800); }
u16 *hw_obj_tiles(void) { return (u16 *)0x06010000; }
u16 *hw_pal_bg(void)    { return (u16 *)0x05000000; }
u16 *hw_pal_obj(void)   { return (u16 *)0x05000200; }
u16 *hw_oam_shadow(void){ return oam_shadow; }
void hw_set_scroll(int bg, int x, int y) { scroll[bg][0] = x; scroll[bg][1] = y; }

/* SRAM : bus cartouche partage avec la ROM -> ces fonctions DOIVENT s'executer depuis l'IWRAM (code ARM). */
#define IWRAM_CODE __attribute__((section(".iwram"), long_call, noinline, target("arm")))
IWRAM_CODE void hw_sram_read(u32 off, u8 *dst, u32 n) {
    volatile u8 *s = (volatile u8 *)0x0E000000;
    for (u32 i = 0; i < n; i++) dst[i] = s[off + i];
}
IWRAM_CODE void hw_sram_write(u32 off, const u8 *src, u32 n) {
    volatile u8 *s = (volatile u8 *)0x0E000000;
    for (u32 i = 0; i < n; i++) s[off + i] = src[i];
}
void hw_snd_tone(u16 freq, u16 env, u16 duty) {
    SND1_L = 0; SND1_H = (u16)(env | duty); SND1_X = (u16)(0x8000 | (freq & 0x7FF));
}
void hw_snd_noise(u16 env, u16 ctl) { SND4_L = env; SND4_H = (u16)(0x8000 | ctl); }
