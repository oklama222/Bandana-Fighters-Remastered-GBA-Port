#include "game.h"
static u8 arena_col[30 * 20];
static level_t arena = { 30, 20, arena_col };
const level_t *g_level = &arena;
void level_init_arena(void) {
    for (int i = 0; i < 30 * 20; i++) arena_col[i] = 0;
    for (int y = 18; y < 20; y++) for (int x = 0; x < 30; x++) arena_col[y * 30 + x] = 1;   /* sol */
    g_level = &arena;
}
int level_solid(int tx, int ty) {
    if (tx < 0 || tx >= g_level->w_tiles) return 1;      /* murs invisibles gauche/droite */
    if (ty < 0) return 0;                                /* ciel ouvert */
    if (ty >= g_level->h_tiles) return 1;
    return g_level->col[ty * g_level->w_tiles + tx];
}
int box_solid(int x0, int y0, int x1, int y1) {
    for (int ty = y0 >> 3; ty <= (y1 >> 3); ty++)
        for (int tx = x0 >> 3; tx <= (x1 >> 3); tx++)
            if (level_solid(tx, ty)) return 1;
    return 0;
}
void body_move(body_t *b) {
    int w = b->w, h = b->h;
    fx nx = b->x + b->vx;
    int l = FX_INT(nx), r = l + w - 1, t = FX_INT(b->y), bt = t + h - 1;
    if (box_solid(l, t, r, bt)) {
        if (b->vx > 0) nx = FX((((r >> 3) << 3) - w));
        else if (b->vx < 0) nx = FX((((l >> 3) + 1) << 3));
        b->vx = 0;
    }
    b->x = nx;
    fx ny = b->y + b->vy;
    l = FX_INT(b->x); r = l + w - 1; t = FX_INT(ny); bt = t + h - 1;
    b->ground = 0;
    if (box_solid(l, t, r, bt)) {
        if (b->vy > 0) { ny = FX((((bt >> 3) << 3) - h)); b->ground = 1; }
        else if (b->vy < 0) ny = FX((((t >> 3) + 1) << 3));
        b->vy = 0;
    }
    b->y = ny;
    if (!b->ground && b->vy >= 0 && box_solid(l, FX_INT(b->y) + h, r, FX_INT(b->y) + h)) { b->ground = 1; b->vy = 0; }   /* sonde : pieds poses sur le sol */
}
void body_push(body_t *b, int dx_px) {
    fx ovx = b->vx, ovy = b->vy;
    b->vx = FX(dx_px); b->vy = 0;
    body_move(b);
    b->vx = ovx; b->vy = ovy;
}
int rect_hit(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
    return ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah;
}
