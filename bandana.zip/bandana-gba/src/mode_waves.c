/* MODE VAGUES : COMBAT -> PORTE -> CHOIX DE BONUS -> VAGUE SUIVANTE. Bonus cumulatifs pendant toute la run. */
#include "game.h"
enum { WP_COMBAT, WP_DOOR, WP_BONUS, WP_OVER };
#define DOOR_X 216
static struct { int wave, boss, phase, kills, needed, spawned, timer, interval, toast, cursor, over_t, paused, lock; u8 offer[3]; } W;
int waves_phase(void) { return W.phase; }
int waves_wave(void) { return W.wave; }
int waves_kills(void) { return W.kills; }
int waves_needed(void) { return W.needed; }
int waves_offer(int i) { return W.offer[i]; }
int waves_is_boss(void) { return W.boss; }
int waves_lock(void) { return W.lock; }
int waves_cursor(void) { return W.cursor; }

static void toast(const char *a, const char *b, int frames) {
    ui_clear_rows(UI_TXT, 6, 4);
    ui_text_center(UI_TXT, 6, a, TXT_YELLOW);
    if (b) ui_text_center(UI_TXT, 8, b, TXT_WHITE);
    W.toast = frames;
}
static void wave_start(int n) {
    W.wave = n; W.boss = (n % 5 == 0);
    W.needed = W.boss ? 1 : MIN(6 + (n - 1) * 2, 26);                      /* min(6 + 2(n-1), 26) */
    W.kills = W.spawned = W.timer = 0;
    W.interval = MAX(39, 90 - (36 * n) / 10);                              /* max(650, 1500 - 60n) ms en frames */
    W.phase = WP_COMBAT;
    enemies_clear(); proj_clear(); fxp_clear();
    g_player.b.x = FX(SCREEN_W / 2 - g_player.b.w / 2); g_player.b.vx = 0;
    g_boss.active = 0;
    if (W.boss) { boss_spawn(g_run.score); toast("VAGUE BOSS", W.wave < 10 ? "LE CAID" : "LE CAID !", 90); }
    else { char b[8] = "VAGUE "; (void)b; toast("VAGUE", 0, 90); ui_num(UI_TXT, 17, 6, n, 2, TXT_YELLOW); }
}
static void on_enemy_down(void) {
    if (W.phase != WP_COMBAT || W.boss) return;
    if (++W.kills >= W.needed) { W.phase = WP_DOOR; proj_clear_hostile(); toast("VAGUE FINIE", "VA A LA PORTE >", 150); sfx_play(SFX_DOOR); }
}
static void on_boss_down(void) {
    if (W.phase != WP_COMBAT || !W.boss) return;
    W.kills = 1; W.phase = WP_DOOR; proj_clear_hostile(); toast("BOSS VAINCU", "VA A LA PORTE >", 150); sfx_play(SFX_DOOR);
}
static void on_player_down(void) { W.phase = WP_OVER; W.over_t = 0; }
static void draw_offer(void) {
    ui_clear_rows(UI_TXT, 4, 28);
    ui_panel(2, 4, 26, 14);
    ui_text_center(UI_TXT, 5, "CHOISIS UN BONUS", TXT_YELLOW);
    for (int i = 0; i < 3; i++) {
        ui_text(UI_TXT, 4, 8 + i * 3, i == W.cursor ? ">" : " ", TXT_YELLOW);
        ui_text(UI_TXT, 6, 8 + i * 3, g_bonus_defs[W.offer[i]].name, i == W.cursor ? TXT_WHITE : TXT_CYAN);
    }
}
static void reached_door(void) {
    if (W.phase != WP_DOOR) return;                                          /* ne peut etre declenche qu'une fois */
    W.phase = WP_BONUS; W.cursor = 0; W.lock = 30;                           /* 0,5 s : evite de valider un bonus en martelant A */
    u8 pool[B_COUNT]; for (int i = 0; i < B_COUNT; i++) pool[i] = (u8)i;
    int n = B_COUNT;
    for (int k = 0; k < 3; k++) { int r = rng_range(n); W.offer[k] = pool[r]; pool[r] = pool[--n]; }   /* 3 bonus distincts */
    sfx_play(SFX_DOOR);
    save_write();
    hud_reset();
    draw_offer();
}
static void enter(void) {
    cam_init(SCREEN_W, SCREEN_H); level_init_arena();
    g_run.score = 0; g_run.coins = 0;
    bonus_reset(); coins_clear(); fxp_clear(); proj_clear(); enemies_clear(); g_boss.active = 0;
    g_hook_enemy_down = on_enemy_down; g_hook_boss_down = on_boss_down; g_hook_player_down = on_player_down;
    player_init(g_save.sel_char);
    W.paused = 0;
    hud_reset();
    wave_start(1);
}
static void leave(void) { g_hook_enemy_down = 0; g_hook_boss_down = 0; g_hook_player_down = 0; }
static void update(void) {
    if (W.phase == WP_BONUS) {
        if (W.lock) { W.lock--; return; }
        if (g_in.pressed & KEY_UP)   { W.cursor = (W.cursor + 2) % 3; draw_offer(); }
        if (g_in.pressed & KEY_DOWN) { W.cursor = (W.cursor + 1) % 3; draw_offer(); }
        if (g_in.pressed & KEY_A) {
            bonus_apply(W.offer[W.cursor]);                                  /* applique immediatement, conserve ensuite */
            sfx_play(SFX_BONUS);
            ui_clear(UI_PNL); ui_clear_rows(UI_TXT, 4, 28);
            hud_reset();
            wave_start(W.wave + 1);
        }
        return;
    }
    if (W.phase == WP_OVER) {
        if (W.over_t == 0) {
            if (W.wave > g_save.best_wave) g_save.best_wave = (u16)MIN(W.wave, 99);
            save_write();
            ui_clear_rows(UI_TXT, 4, 28); ui_panel(4, 5, 22, 10);
            ui_text_center(UI_TXT, 6, "GAME OVER", TXT_RED);
            ui_text(UI_TXT, 7, 9, "VAGUE", TXT_WHITE); ui_num(UI_TXT, 14, 9, W.wave, 3, TXT_WHITE);
            ui_text(UI_TXT, 7, 11, "PIECES", TXT_YELLOW); ui_num(UI_TXT, 14, 11, g_run.coins, 3, TXT_YELLOW);
        }
        if (W.over_t < 255) W.over_t++;
        player_update(); fxp_update(); enemies_update(); proj_update(); coins_update();
        if (W.over_t > 60 && (g_in.pressed & KEY_START)) { ui_clear(UI_PNL); game_set_mode(&MODE_TITLE); }
        return;
    }
    if (g_in.pressed & KEY_START) {                                          /* pause */
        W.paused = !W.paused;
        if (W.paused) { toast("PAUSE", "SELECT = MENU", 0); }
        else { ui_clear_rows(UI_TXT, 6, 4); W.toast = 0; }
    }
    if (W.paused) {
        if (g_in.pressed & KEY_SELECT) { save_write(); game_set_mode(&MODE_TITLE); }
        return;
    }
    player_update(); enemies_update(); boss_update(); proj_update(); coins_update(); fxp_update();
    if (W.toast > 0 && --W.toast == 0) ui_clear_rows(UI_TXT, 6, 4);
    if (W.phase == WP_COMBAT && !W.boss) {
        W.timer++;
        if (W.spawned < W.needed && W.timer >= W.interval && enemies_alive() < ENEMY_ALIVE_MAX) {
            if (enemies_spawn_random()) { W.timer = 0; W.spawned++; }
        }
    } else if (W.phase == WP_DOOR && !g_player.dead && player_center_x() >= DOOR_X - 4) reached_door();
    cam_follow(player_center_x());
}
static void render(void) {
    if (W.phase != WP_BONUS) {
        if (W.phase == WP_DOOR) spr_world(DOOR_X, GROUND_Y - 32, SPR_16x32, TILE_DOOR, PAL_MISC, 0);
        coins_render(); enemies_render(); boss_render(); player_render(); proj_render(); fxp_render();
    }
    hud_update(W.wave, W.kills, W.needed, W.boss);
}
const game_mode_t MODE_WAVES = { enter, update, render, leave };
