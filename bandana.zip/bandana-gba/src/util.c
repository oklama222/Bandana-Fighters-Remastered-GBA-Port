#include "game.h"
static u32 rs = 0x1234567u;
void rng_seed(u32 s) { rs = s ? s : 0x1234567u; }
u32 rng_u32(void) { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return rs; }
int rng_range(int n) { return n <= 1 ? 0 : (int)((rng_u32() >> 8) % (u32)n); }
int isin(int phase) {                       /* approximation parabolique, sans table */
    int p = phase & 255, neg = p >= 128;
    if (neg) p -= 128;
    int v = (p * (128 - p)) >> 4;           /* 0..256 */
    return neg ? -v : v;
}
input_t g_in;
void input_update(void) {
    u16 k = hw_keys();
    g_in.pressed = (u16)(k & ~g_in.held);
    g_in.released = (u16)(~k & g_in.held);
    g_in.held = k;
}
