/* Art PLACEHOLDER genere en code : vrais formats GBA (sprites 4bpp 1D, tuiles BG 4bpp, palettes 15 bits).
   Les vrais PNG (grit) remplaceront ces fonctions sans toucher au moteur : memes index de tuiles/palettes. */
#include "game.h"
static u8 cv[32][32];
static int cw, ch;
static void cv_clear(int w, int h) { cw = w; ch = h; for (int y = 0; y < 32; y++) for (int x = 0; x < 32; x++) cv[y][x] = 0; }
static void cv_px(int x, int y, int c) { if (x >= 0 && y >= 0 && x < cw && y < ch) cv[y][x] = (u8)c; }
static void cv_rect(int x0, int y0, int x1, int y1, int c) { for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) cv_px(x, y, c); }
static void cv_ell(int cx, int cy, int rx, int ry, int c) {
    for (int y = cy - ry; y <= cy + ry; y++) for (int x = cx - rx; x <= cx + rx; x++) {
        int dx = x - cx, dy = y - cy;
        if (dx * dx * ry * ry + dy * dy * rx * rx <= rx * rx * ry * ry) cv_px(x, y, c);
    }
}
static void cv_outline(void) {                       /* contour sombre (index 1) autour des pixels peints */
    u8 t[32][32];
    for (int y = 0; y < ch; y++) for (int x = 0; x < cw; x++) t[y][x] = cv[y][x];
    for (int y = 0; y < ch; y++) for (int x = 0; x < cw; x++) if (!t[y][x]) {
        if ((x > 0 && t[y][x-1]) || (x < cw-1 && t[y][x+1]) || (y > 0 && t[y-1][x]) || (y < ch-1 && t[y+1][x])) cv[y][x] = 1;
    }
}
/* canvas -> tuiles 4bpp, layout 1D (rangee par rangee) */
static void cv_blit(u16 *vram, int tile0, int w, int h) {
    int tw = w / 8;
    for (int ty = 0; ty < h / 8; ty++) for (int tx = 0; tx < tw; tx++) {
        u16 *t = vram + (tile0 + ty * tw + tx) * 16;
        for (int y = 0; y < 8; y++) for (int k = 0; k < 2; k++) {
            u16 v = 0;
            for (int i = 0; i < 4; i++) v |= (u16)((cv[ty*8+y][tx*8+k*4+i] & 15) << (i * 4));
            t[y * 2 + k] = v;
        }
    }
}
/* ---------- humanoides 16x32 : index 1 contour, 2 peau, 3 haut, 4 bandana, 5 cheveux, 6 blanc, 7 pantalon ---------- */
typedef struct { u8 hair, wide, item; } style_t;
static const style_t styles[8] = {
    {0,0,1}, /* RYDER afro   */ {1,0,1}, /* LUMA cheveux longs */ {2,0,1}, /* JACOB court */ {3,1,1}, /* WALLACE massif */
    {4,0,1}, /* KD pointes   */ {5,0,0}, /* VOYOU bonnet */ {6,0,0}, /* FONCEUR crete */ {7,0,2}, /* LANCEUR capuche + bouteille */
};
static void draw_human(const style_t *s, int frame) {
    cv_clear(16, 32);
    int c0 = s->wide ? 2 : 4, c1 = s->wide ? 13 : 11;
    int lh = 30, rh = 30, lx = s->wide ? 4 : 5, rx = s->wide ? 8 : 8;
    if (frame == 1) lh = 27; else if (frame == 2) rh = 27;
    if (frame == 3) { lh = 26; rh = 29; }
    cv_rect(lx, 22, lx + 2, lh, 7); cv_rect(rx, 22, rx + 2 + (s->wide ? 1 : 0), rh, 7);
    cv_rect(lx, lh, lx + 3, lh + 1, 6); cv_rect(rx, rh, rx + 3 + (s->wide ? 1 : 0), rh + 1, 6);   /* chaussures */
    cv_rect(c0, 13, c1, 21, 3);                                                                  /* torse */
    cv_rect(c1, 14, MIN(c1 + 2, 15), 16, 2);                                                     /* bras */
    if (s->item == 1) cv_rect(MIN(c1 + 2, 14), 15, 15, 16, 5);                                   /* arme */
    if (s->item == 2) cv_rect(MIN(c1 + 2, 14), 12, MIN(c1 + 3, 15), 16, 6);                      /* bouteille */
    int h = s->hair;                                                                             /* cheveux (derriere la tete) */
    if (h == 0) cv_ell(8, 5, 7, 5, 5);
    if (h == 1) { cv_rect(3, 3, 12, 6, 5); cv_rect(2, 5, 4, 15, 5); }
    if (h == 2 || h == 3) cv_rect(4, 3, 11, 5, 5);
    if (h == 4) { cv_rect(4, 3, 11, 4, 5); cv_rect(5, 1, 6, 2, 5); cv_rect(8, 0, 9, 2, 5); cv_rect(11, 1, 12, 2, 5); }
    if (h == 5) cv_rect(3, 3, 12, 5, 5);
    if (h == 6) { cv_rect(6, 1, 9, 4, 5); cv_rect(5, 3, 11, 4, 5); }
    if (h == 7) { cv_ell(8, 7, 7, 6, 3); }
    cv_rect(4, 5, 11, 12, 2);                                                                    /* tete */
    cv_rect(4, 5, 11, 6, 4);                                                    /* bandana */
    cv_rect(1, 6 + (frame == 1), 3, 7 + (frame == 1), 4);                                        /* pan du bandana */
    cv_px(9, 9, 6); cv_px(10, 9, 1);                                                             /* oeil */
    cv_outline();
}
static void draw_bat(int frame) {
    cv_clear(16, 16);
    cv_ell(8, 8, 2, 3, 3); cv_px(7, 4, 3); cv_px(9, 4, 3); cv_px(7, 7, 6); cv_px(9, 7, 6);
    if (frame == 0) { cv_rect(2, 2, 5, 7, 4); cv_rect(10, 2, 13, 7, 4); cv_px(1, 4, 4); cv_px(14, 4, 4); }
    else            { cv_rect(1, 8, 5, 11, 4); cv_rect(10, 8, 14, 11, 4); cv_px(0, 10, 4); cv_px(15, 10, 4); }
    cv_outline();
}
static void draw_boss(int frame) {                    /* LE CAID 32x32 */
    cv_clear(32, 32);
    cv_rect(9, 22, 14, 30, 7); cv_rect(17, 22, 22, 30, 7); cv_rect(8, 30, 14, 31, 6); cv_rect(17, 30, 23, 31, 6);
    cv_rect(6, 12, 25, 22, 3);
    if (frame == 0) { cv_rect(2, 13, 5, 24, 2); cv_rect(26, 13, 29, 24, 2); }
    else            { cv_rect(2, 3, 5, 14, 2);  cv_rect(26, 3, 29, 14, 2); }
    cv_rect(10, 2, 21, 12, 2); cv_rect(9, 1, 22, 4, 5); cv_rect(10, 6, 21, 7, 4); cv_rect(5, 6, 9, 8, 4);
    cv_px(17, 9, 6); cv_px(18, 9, 1); cv_px(13, 9, 6); cv_px(14, 9, 1); cv_rect(13, 11, 18, 11, 1);
    cv_outline();
}
static void small_sprites(u16 *v) {
    cv_clear(8, 8); cv_ell(4, 4, 2, 2, 1); cv_blit(v, TILE_BULLET, 8, 8);                 /* tir joueur (jaune) */
    cv_clear(8, 8); cv_ell(4, 4, 2, 2, 2); cv_px(4, 4, 5); cv_blit(v, TILE_EBULLET, 8, 8);  /* tir ennemi (rouge) */
    cv_clear(8, 8); cv_ell(4, 4, 3, 3, 3); cv_ell(4, 4, 1, 2, 4); cv_blit(v, TILE_COIN, 8, 8);
    cv_clear(8, 8); cv_px(4,0,8); cv_px(4,1,8); cv_px(4,6,8); cv_px(4,7,8); cv_px(0,4,8); cv_px(1,4,8); cv_px(6,4,8); cv_px(7,4,8); cv_blit(v, TILE_CROSS, 8, 8);
    cv_clear(8, 8); cv_px(4,1,9); cv_px(3,3,9); cv_px(4,3,9); cv_px(5,3,9); cv_px(2,4,9); cv_px(3,4,5); cv_px(4,4,5); cv_px(5,4,5); cv_px(6,4,9);
    cv_px(3,5,9); cv_px(4,5,9); cv_px(5,5,9); cv_px(4,7,9); cv_blit(v, TILE_SPARK, 8, 8);
    cv_clear(8, 8); cv_ell(4, 4, 3, 2, 1); cv_blit(v, TILE_BIGDOT, 8, 8);
}
static void draw_door(void) {
    cv_clear(16, 32);
    cv_rect(0, 0, 15, 31, 6); cv_rect(2, 3, 13, 31, 7); cv_rect(7, 12, 8, 24, 5); cv_rect(5, 20, 10, 21, 5); cv_rect(6, 22, 9, 23, 5);
    cv_outline();
}
#define PAL(bank, i, col) (po[(bank) * 16 + (i)] = (col))
static void set_actor_pal(int bank, u32 skin, u32 body, u32 band, u32 hair, u32 pants) {
    u16 *po = hw_pal_obj();
    PAL(bank,0,0); PAL(bank,1,C24(0x0a0612)); PAL(bank,2,C24(skin)); PAL(bank,3,C24(body)); PAL(bank,4,C24(band));
    PAL(bank,5,C24(hair)); PAL(bank,6,C24(0xf4f4f4)); PAL(bank,7,C24(pants));
}
void art_set_player_palette(int c) {
    const char_def_t *d = &g_chars[c];
    set_actor_pal(PAL_PLAYER, d->skin, d->body, d->bandana, d->hair, 0x22252e);
}
void art_update_player_palette(int c, u32 frame) {
    if (!g_chars[c].rainbow) return;
    static const u32 rb[6] = { 0xff3b3b, 0xff9f1c, 0xffe94a, 0x3ecf6b, 0x3b82f6, 0xb15cff };
    hw_pal_obj()[PAL_PLAYER * 16 + 4] = C24(rb[(frame >> 3) % 6]);
}
/* ---------- fond : tuiles BG ---------- */
enum { T_SKYA = 1, T_SKYB, T_BLD, T_WIN_OFF, T_WIN_ON, T_NEON, T_STREET_TOP, T_STREET, T_PANEL_FILL, T_PANEL_TOP, T_PANEL_BOT, T_PANEL_L, T_PANEL_R };
static void bg_solid(u16 *t, int tile, int c) { cv_clear(8, 8); cv_rect(0, 0, 7, 7, c); cv_blit(t, tile, 8, 8); }
static void build_bg_tiles(void) {
    u16 *t = hw_bg_tiles();
    cv_clear(8, 8); cv_blit(t, 0, 8, 8);
    bg_solid(t, T_SKYA, 1); bg_solid(t, T_SKYB, 2); bg_solid(t, T_BLD, 3);
    cv_clear(8, 8); cv_rect(0,0,7,7,3); cv_rect(2,2,5,5,5); cv_blit(t, T_WIN_OFF, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,3); cv_rect(2,2,5,5,6); cv_blit(t, T_WIN_ON, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,3); cv_rect(0,0,7,1,7); cv_blit(t, T_NEON, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,8); cv_rect(0,0,7,1,9); cv_blit(t, T_STREET_TOP, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,8); cv_rect(1,4,4,4,9); cv_blit(t, T_STREET, 8, 8);
    bg_solid(t, T_PANEL_FILL, 10);
    cv_clear(8, 8); cv_rect(0,0,7,7,10); cv_rect(0,0,7,1,11); cv_blit(t, T_PANEL_TOP, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,10); cv_rect(0,6,7,7,11); cv_blit(t, T_PANEL_BOT, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,10); cv_rect(0,0,1,7,11); cv_blit(t, T_PANEL_L, 8, 8);
    cv_clear(8, 8); cv_rect(0,0,7,7,10); cv_rect(6,0,7,7,11); cv_blit(t, T_PANEL_R, 8, 8);
}
static void build_arena_map(void) {                  /* ville de nuit : skyline pseudo-aleatoire fixe */
    u16 *m = hw_bg_map(SB_BG0);
    for (int y = 0; y < 32; y++) for (int x = 0; x < 32; x++) m[y * 32 + x] = (u16)(y < 9 ? T_SKYA : T_SKYB);
    int x = 0, seed = 7;
    while (x < 30) {
        seed = (seed * 75 + 74) & 0xFFFF;
        int bw = 2 + (seed & 1), bh = 4 + ((seed >> 3) % 6);
        for (int bx = x; bx < x + bw && bx < 30; bx++) for (int by = 18 - bh; by < 18; by++) {
            int t = T_BLD;
            if (by == 18 - bh) t = ((seed >> 5) & 1) ? T_NEON : T_BLD;
            else if (by > 18 - bh + 1 && ((bx + by + seed) & 1)) t = (((bx * 7 + by * 3 + seed) & 3) == 0) ? T_WIN_ON : T_WIN_OFF;
            m[by * 32 + bx] = (u16)t;
        }
        x += bw;
    }
    for (int i = 0; i < 30; i++) { m[18 * 32 + i] = T_STREET_TOP; m[19 * 32 + i] = T_STREET; }
}
void art_init(void) {
    u16 *pb = hw_pal_bg();
    static const u32 bgc[16] = { 0x14082b, 0x14082b, 0x2a0f4a, 0x1a1030, 0x261845, 0x3a2a5c, 0xffd23e, 0xff3ea5,
                                 0x2b2b3a, 0x5c5c78, 0x0c0818, 0xffd23e, 0xe5302f, 0x3a1020, 0xffffff, 0x36e0ff };
    for (int i = 0; i < 16; i++) pb[i] = C24(bgc[i]);
    static const u32 txt[5] = { 0xffffff, 0xffd23e, 0xff5a54, 0x3ecf6b, 0x36e0ff };
    for (int b = 0; b < 5; b++) { pb[(b + 1) * 16] = 0; pb[(b + 1) * 16 + 1] = C24(txt[b]); }
    build_bg_tiles();
    build_arena_map();
    u16 *v = hw_obj_tiles();
    for (int s = 0; s < 8; s++) for (int f = 0; f < 4; f++) { draw_human(&styles[s], f); cv_blit(v, TILE_HUMAN(s, f), 16, 32); }
    for (int f = 0; f < 2; f++) { draw_bat(f); cv_blit(v, TILE_BAT(f), 16, 16); draw_boss(f); cv_blit(v, TILE_BOSS(f), 32, 32); }
    small_sprites(v); draw_door(); cv_blit(v, TILE_DOOR, 16, 32);
    art_set_player_palette(CH_RYDER);
    set_actor_pal(PAL_GRUNT,   0xc8a07a, 0x4b4f58, 0x8b3fd8, 0x1a1a22, 0x2d2f38);
    set_actor_pal(PAL_RUSHER,  0xb98a66, 0x7a3a64, 0x8b3fd8, 0x241028, 0x3a2a40);
    set_actor_pal(PAL_THROWER, 0xd2b48c, 0x3f4658, 0x8b3fd8, 0x1a1a22, 0x262b38);
    u16 *po = hw_pal_obj();
    PAL(PAL_BAT,0,0); PAL(PAL_BAT,1,C24(0x0a0612)); PAL(PAL_BAT,3,C24(0x4a1f8a)); PAL(PAL_BAT,4,C24(0x6b2fb8)); PAL(PAL_BAT,6,C24(0xff4d6d));
    set_actor_pal(PAL_BOSS, 0xc89870, 0x5b2a9a, 0x8b3fd8, 0x1a1020, 0x2a1448);
    PAL(PAL_MISC,0,0); PAL(PAL_MISC,1,C24(0xffe94a)); PAL(PAL_MISC,2,C24(0xff3b3b)); PAL(PAL_MISC,3,C24(0xffc21a)); PAL(PAL_MISC,4,C24(0xb8860b));
    PAL(PAL_MISC,5,C24(0xffffff)); PAL(PAL_MISC,6,C24(0x6b3f1d)); PAL(PAL_MISC,7,C24(0x3ecf6b)); PAL(PAL_MISC,8,C24(0x36e0ff)); PAL(PAL_MISC,9,C24(0xff9f1c));
    for (int i = 1; i < 16; i++) PAL(PAL_FLASH, i, C24(0xffffff));
    PAL(PAL_FLASH, 1, C24(0x2a2a2a));
}
