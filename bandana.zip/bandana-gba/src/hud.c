#include "game.h"
/* HUD sur BG1 (materiel) : mise a jour uniquement quand une valeur change -> cout quasi nul par frame. */
static int c_hp, c_max, c_wave, c_kills, c_need, c_boss, c_coins, c_bhp, c_bmax;
void hud_reset(void) {
    c_hp = c_max = c_wave = c_kills = c_need = c_boss = c_coins = c_bhp = c_bmax = -1;
    ui_clear_rows(UI_TXT, 0, 4);
    ui_text(UI_TXT, 0, 0, "HP", TXT_WHITE);
}
void hud_update(int wave, int kills, int need, int is_boss) {
    int hp = g_player.hp, mx = g_player.maxhp;
    if (hp != c_hp || mx != c_max) {
        c_hp = hp; c_max = mx;
        ui_bar(2, 0, hp, mx, 8);
        ui_num(UI_TXT, 10, 0, hp, 3, hp * 4 < mx ? TXT_RED : TXT_WHITE);
    }
    if (wave != c_wave) { c_wave = wave; ui_text(UI_TXT, 14, 0, "V", TXT_YELLOW); ui_num(UI_TXT, 15, 0, wave, 2, TXT_YELLOW); }
    if (kills != c_kills || need != c_need || is_boss != c_boss) {
        c_kills = kills; c_need = need; c_boss = is_boss;
        if (is_boss) ui_text(UI_TXT, 18, 0, "BOSS ", TXT_RED);
        else { ui_num(UI_TXT, 18, 0, kills, 2, TXT_CYAN); ui_text(UI_TXT, 20, 0, "/", TXT_CYAN); ui_num(UI_TXT, 21, 0, need, 2, TXT_CYAN); }
    }
    int cn = MIN(g_run.coins, 9999);                                   /* 4 chiffres max a l'ecran */
    if (cn != c_coins) { c_coins = cn; ui_text(UI_TXT, 25, 0, "C", TXT_YELLOW); ui_num(UI_TXT, 26, 0, cn, 4, TXT_YELLOW); }
    int bh = (g_boss.active && !g_boss.dead) ? g_boss.hp : 0, bm = g_boss.active ? g_boss.maxhp : 0;
    if (bh != c_bhp || bm != c_bmax) {
        c_bhp = bh; c_bmax = bm;
        ui_clear_rows(UI_TXT, 2, 2);
        if (bm) { ui_text(UI_TXT, 0, 2, "BOSS", TXT_RED); ui_bar(5, 2, bh, bm, 12); }
    }
}
