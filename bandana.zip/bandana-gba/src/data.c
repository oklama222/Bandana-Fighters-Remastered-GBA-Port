/* Tables de donnees portees du jeu HTML (valeurs x0.6 pour l'echelle 240x160, ms -> frames a 60 Hz).
   speed (fx/frame) = px/s * 0.6 / 60 * 256 = px/s * 2.56 */
#include "game.h"
const char_def_t g_chars[CH_COUNT] = {
 { "RYDER",  ART_RYDER,   320, 256, 256, 256, 0,0,0, 0x6b4327, 0x2b3a4a, 0x3ecf6b, 0x151515 },
 { "LUMA",   ART_LUMA,    256, 333, 256, 256, 0,0,0, 0xcf9866, 0x3a3550, 0xf4d33c, 0x3b2418 },
 { "JACOB",  ART_JACOB,   256, 256, 320, 256, 0,0,0, 0xf2c9a0, 0x3a4a3c, 0x3b82f6, 0x4a3520 },
 { "WALLACE",ART_WALLACE, 256, 256, 256, 333, 0,0,0, 0xa5703f, 0x4a3434, 0xe5302f, 0x201510 },
 { "KD",     ART_KD,      256, 256, 256, 256, 1,1,1, 0xffffff, 0xffffff, 0xff00ff, 0xdddddd },
};
const weapon_def_t g_weapons[W_COUNT] = {
 /* name       melee dmg cd  range speed pel spr jit pierce price pw ph */
 { "PISTOLET",   0,  7, 25, 204, 1638, 1, 0,  0, 0,   0, 4, 3 },
 { "FUSIL POMPE",0,  4, 38, 126, 1536, 4, 38, 0, 0,  60, 3, 3 },
 { "MITRAILL.",  0,  5,  9, 192, 1741, 1, 0, 15, 0, 140, 4, 3 },
 { "PERFORANT",  0, 20, 42, 336, 2509, 1, 0,  0, 1, 220, 6, 4 },
 { "GANT ELEC.", 1, 15, 29,  31,    0, 1, 0,  0, 0, 380, 0, 0 },
};
const enemy_def_t g_enemy_defs[E_TYPES] = {
 /* name      hp  speed dmg rng cd  pts  w  h ranged fly art           pal */
 { "VOYOU",   28, 217,  7, 23, 60, 10, 12, 28, 0, 0, ART_GRUNT,   PAL_GRUNT },
 { "FONCEUR", 18, 384,  6, 20, 45, 14, 10, 26, 0, 0, ART_RUSHER,  PAL_RUSHER },
 { "LANCEUR", 16, 141,  5, 138,102, 18, 10, 26, 1, 0, ART_THROWER,PAL_THROWER },
 { "CHAUVE-S",12, 320,  6, 16, 90, 12, 14, 10, 0, 1, 0,           PAL_BAT },
};
const bonus_def_t g_bonus_defs[B_COUNT] = {
 { "DEGATS +20%" }, { "VIE MAX +20" }, { "SOIN 50%" }, { "VITESSE +12%" },
 { "CADENCE +15%" }, { "DEFENSE +15%" }, { "PIECES +20%" },
};
run_bonus_t g_bonus;
run_t g_run;
static u32 acc[5];   /* dmg, speed, fire, defense, coins : 16.16 (pas de derive d'arrondi cumulee) */
static void publish(void) {
    g_bonus.dmg = (acc[0] + 128) >> 8; g_bonus.speed = (acc[1] + 128) >> 8; g_bonus.fire = (acc[2] + 128) >> 8;
    g_bonus.defense = (acc[3] + 128) >> 8; g_bonus.coins = (acc[4] + 128) >> 8;
}
void bonus_reset(void) { for (int i = 0; i < 5; i++) acc[i] = 65536; publish(); }
static void mul(int i, u32 m, u32 lo, u32 hi) { u32 v = (u32)(((unsigned long long)acc[i] * m) >> 16); acc[i] = CLAMP(v, lo, hi); }
void bonus_apply(int id) {                       /* multiplicatif pour les taux, additif pour les PV */
    switch (id) {
    case B_DMG:     mul(0, 78643, 0, 12u << 16); break;       /* x1.20 */
    case B_MAXHP:   g_player.maxhp += 20; g_player.hp += 20; break;
    case B_HEAL:    player_heal((g_player.maxhp + 1) / 2); break;
    case B_SPEED:   mul(1, 73400, 0, 3u << 16); break;        /* x1.12 */
    case B_FIRE:    mul(2, 55706, 16384, 1u << 20); break;    /* x0.85, plancher x0.25 */
    case B_DEFENSE: mul(3, 55706, 16384, 1u << 20); break;    /* x0.85, plancher x0.25 */
    case B_COINS:   mul(4, 78643, 0, 12u << 16); break;       /* x1.20 */
    }
    publish();
}
