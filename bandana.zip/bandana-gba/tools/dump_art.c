/* Outil PC : exporte tuiles OBJ + palettes pour controle visuel (tools/render_art.py). */
#include "game.h"
#include <stdio.h>
int main(void) {
    hw_init(); art_init(); ui_init();
    FILE *f = fopen("/tmp/art.bin", "wb");
    fwrite(hw_obj_tiles(), 2, 512 * 16, f); fwrite(hw_pal_obj(), 2, 256, f);
    fwrite(hw_bg_tiles(), 2, 512 * 16, f);  fwrite(hw_pal_bg(), 2, 256, f);
    fwrite(hw_bg_map(SB_BG0), 2, 1024, f);
    fclose(f); return 0;
}
