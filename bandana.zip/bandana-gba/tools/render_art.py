import struct, sys
from PIL import Image
d = open('/tmp/art.bin','rb').read()
u = struct.unpack('<%dH' % (len(d)//2), d)
objt, pobj, bgt, pbg, bgm = u[:8192], u[8192:8448], u[8448:16640], u[16640:16896], u[16896:17920]
def rgb(c): return ((c&31)*255//31, ((c>>5)&31)*255//31, ((c>>10)&31)*255//31)
def tile(t, i):
    px = [[0]*8 for _ in range(8)]
    for y in range(8):
        for k in range(2):
            v = t[i*16+y*2+k]
            for j in range(4): px[y][k*4+j] = (v >> (j*4)) & 15
    return px
def blit(img, t, pal, bank, tid, ox, oy, S=4):
    p = tile(t, tid)
    for y in range(8):
        for x in range(8):
            c = p[y][x]
            col = rgb(pal[bank*16+c]) if c else (40,40,50)
            for dy in range(S):
                for dx in range(S): img.putpixel((ox+x*S+dx, oy+y*S+dy), col)
def sprite(img, tid, w, h, bank, ox, oy):
    for ty in range(h//8):
        for tx in range(w//8): blit(img, objt, pobj, bank, tid+ty*(w//8)+tx, ox+tx*32, oy+ty*32)
img = Image.new('RGB', (900, 330), (40,40,50))
x = 4
for s, bank in [(0,0),(1,0),(2,0),(3,0),(4,0),(5,1),(6,2),(7,3)]:
    sprite(img, s*32, 16, 32, bank, x, 4); x += 68
for f in range(4): sprite(img, f*8, 16, 32, 0, 4+f*68, 140)      # Ryder 4 frames
sprite(img, 256, 16, 16, 4, 290, 140); sprite(img, 260, 16, 16, 4, 360, 140)
sprite(img, 264, 32, 32, 5, 430, 140); sprite(img, 280, 32, 32, 5, 570, 140)
for i, t in enumerate([296,297,298,299,300,301]): sprite(img, t, 8, 8, 6, 4+i*40, 280)
sprite(img, 304, 16, 32, 6, 780, 140)
img.save('/tmp/sprites.png')
# decor 240x160
bg = Image.new('RGB', (240*3, 160*3))
for ty in range(20):
    for tx in range(30):
        e = bgm[ty*32+tx]; p = tile(bgt, e & 0x3FF)
        for y in range(8):
            for x in range(8):
                col = rgb(pbg[((e>>12)&15)*16+p[y][x]])
                for dy in range(3):
                    for dx in range(3): bg.putpixel(((tx*8+x)*3+dx,(ty*8+y)*3+dy), col)
bg.save('/tmp/bg.png')
