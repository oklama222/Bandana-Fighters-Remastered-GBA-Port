#ifndef BALANCE_H
#define BALANCE_H
/* ===== Reglages d'equilibrage GBA (un seul endroit). Le jeu HTML d'origine n'est pas modifie. =====
   L'ecran GBA (240 px) est plus etroit que le monde du HTML (400 px) : les ennemis arrivent plus vite sur le joueur. */
#define BAL_INVULN_FRAMES        60   /* invincibilite apres un coup (HTML : ~33) */
#define BAL_MELEE_WINDUP         18   /* annonce du coup des ennemis au corps a corps (HTML : 0 = instantane) */
#define BAL_ENEMY_SPEED_PCT      85   /* vitesse des ennemis au sol, % de la valeur du HTML mise a l'echelle */
#define BAL_SPAWN_INTERVAL_PCT  125   /* delai entre apparitions, % de la valeur du HTML */
#endif
