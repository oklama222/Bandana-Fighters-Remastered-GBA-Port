#ifndef HW_H
#define HW_H
#include "types.h"
/* Couche materielle : seul hw_gba.c (ROM) ou test/hw_host.c (tests PC) l'implemente. */
#define KEY_A      0x001
#define KEY_B      0x002
#define KEY_SELECT 0x004
#define KEY_START  0x008
#define KEY_RIGHT  0x010
#define KEY_LEFT   0x020
#define KEY_UP     0x040
#define KEY_DOWN   0x080
#define KEY_R      0x100
#define KEY_L      0x200

#define SB_BG0 28   /* decor            */
#define SB_BG1 29   /* texte / HUD      */
#define SB_BG2 30   /* panneaux de menu */

void hw_init(void);
void hw_vsync(void);
void hw_flush(void);                       /* OAM shadow + scrolls -> materiel */
u16  hw_keys(void);                        /* 1 = appuye */
u16 *hw_bg_tiles(void);                    /* charblock 0 (0x06000000)  */
u16 *hw_bg_map(int screenblock);
u16 *hw_obj_tiles(void);                   /* 0x06010000                */
u16 *hw_pal_bg(void);
u16 *hw_pal_obj(void);
u16 *hw_oam_shadow(void);                  /* 128 * 4 u16               */
void hw_set_scroll(int bg, int x, int y);
void hw_display(int on);                   /* ecran force noir si 0     */
void hw_sram_read(u32 off, u8 *dst, u32 n);
void hw_sram_write(u32 off, const u8 *src, u32 n);
void hw_snd_tone(u16 freq, u16 env, u16 duty);   /* canal 1 (carre)  */
void hw_snd_noise(u16 env, u16 ctl);             /* canal 4 (bruit)  */
#endif
