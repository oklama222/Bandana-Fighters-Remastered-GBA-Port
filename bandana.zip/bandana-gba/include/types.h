#ifndef TYPES_H
#define TYPES_H
typedef unsigned char  u8;  typedef signed char  s8;
typedef unsigned short u16; typedef signed short s16;
typedef unsigned int   u32; typedef signed int   s32;
typedef s32 fx;                      /* virgule fixe 24.8 */
#define FX(n)       ((fx)(n) * 256)
#define FX_INT(v)   ((v) >> 8)
#define SCREEN_W 240
#define SCREEN_H 160
#define ABS(a)   ((a) < 0 ? -(a) : (a))
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define CLAMP(v,lo,hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))
#define ARRAY_LEN(a) ((int)(sizeof(a)/sizeof((a)[0])))
/* Couleur 0xRRGGBB -> RGB555 */
#define C24(h) ((u16)((((h)>>19)&31) | ((((h)>>11)&31)<<5) | ((((h)>>3)&31)<<10)))
#endif
