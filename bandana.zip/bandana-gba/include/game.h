#ifndef GAME_H
#define GAME_H
#include "types.h"
#include "hw.h"
#include "balance.h"

/* ============================ utilitaires ============================ */
void rng_seed(u32 s);
u32  rng_u32(void);
int  rng_range(int n);              /* 0..n-1 */
int  isin(int phase);               /* phase 0..255 -> -256..256 (approx.) */

typedef struct { u16 held, pressed, released; } input_t;
extern input_t g_in;
void input_update(void);

/* ============================ camera ================================= */
typedef struct { int x, y, world_w, world_h, shake_t, shake_amp, sx, sy; } camera_t;
extern camera_t g_cam;
void cam_init(int world_w, int world_h);
void cam_follow(int target_x_px);   /* suit une cible horizontalement (zone morte) */
void cam_shake(int frames, int amp);
void cam_update(void);              /* applique scroll BG + decalage tremblement   */

/* ============================ sprites (OAM) ========================== */
typedef enum { SPR_8, SPR_16, SPR_16x32, SPR_32 } spr_size_t;
#define SPR_HFLIP 1
void spr_begin(void);
void spr_world(int wx, int wy, spr_size_t sz, int tile, int pal, int flags);   /* coordonnees monde */
void spr_end(void);
int  spr_count(void);

/* ============================ art / tuiles =========================== */
#define ART_RYDER 0
#define ART_LUMA 1
#define ART_JACOB 2
#define ART_WALLACE 3
#define ART_KD 4
#define ART_GRUNT 5
#define ART_RUSHER 6
#define ART_THROWER 7
#define TILE_HUMAN(style, frame) ((style) * 32 + (frame) * 8)    /* 16x32 = 8 tuiles */
#define TILE_BAT(frame)   (256 + (frame) * 4)                     /* 16x16 */
#define TILE_BOSS(frame)  (264 + (frame) * 16)                    /* 32x32 */
#define TILE_BULLET 296
#define TILE_EBULLET 297
#define TILE_COIN 298
#define TILE_CROSS 299
#define TILE_SPARK 300
#define TILE_BIGDOT 301
#define TILE_DOOR 304                                             /* 16x32 */
#define PAL_PLAYER 0
#define PAL_GRUNT 1
#define PAL_RUSHER 2
#define PAL_THROWER 3
#define PAL_BAT 4
#define PAL_BOSS 5
#define PAL_MISC 6
#define PAL_FLASH 7
void art_init(void);
void art_set_player_palette(int chr);
void art_update_player_palette(int chr, u32 frame);   /* KD : bandana arc-en-ciel */

/* ============================ UI (texte, barres) ===================== */
#define UI_TXT 0
#define UI_PNL 1
#define TXT_WHITE 1
#define TXT_YELLOW 2
#define TXT_RED 3
#define TXT_GREEN 4
#define TXT_CYAN 5
void ui_init(void);
void ui_clear(int layer);
void ui_clear_rows(int layer, int row, int nrows);
void ui_text(int layer, int col, int row, const char *s, int pal);     /* 2 rangees de tuiles par ligne */
void ui_num(int layer, int col, int row, int v, int width, int pal);   /* nombre cadre a droite */
void ui_bar(int col, int row, int cur, int max, int cells);
void ui_panel(int col, int row, int w, int h);
void ui_text_center(int layer, int row, const char *s, int pal);

/* ============================ monde / collisions ===================== */
typedef struct { fx x, y, vx, vy; u8 w, h; s8 face; u8 ground; } body_t;
typedef struct { int w_tiles, h_tiles; const u8 *col; } level_t;
extern const level_t *g_level;
void level_init_arena(void);
int  level_solid(int tx, int ty);
int  box_solid(int x0, int y0, int x1, int y1);         /* pixels, inclusif */
void body_move(body_t *b);                               /* deplacement + collisions tuiles */
void body_push(body_t *b, int dx_px);
int  rect_hit(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh);
#define GROUND_Y 144          /* y du sol en pixels (haut des tuiles solides) */

/* ============================ donnees ================================ */
typedef struct {
    const char *name; u8 art; u16 speed, jump, dmg, hp;     /* multiplicateurs 8.8 */
    u8 invulnerable, lethal, rainbow; u32 skin, body, bandana, hair;
} char_def_t;
enum { CH_RYDER, CH_LUMA, CH_JACOB, CH_WALLACE, CH_KD, CH_COUNT };
extern const char_def_t g_chars[CH_COUNT];

typedef struct {
    const char *name; u8 melee; s16 dmg; u8 cd; u16 range_px; s16 speed;   /* speed : fx/frame */
    u8 pellets; u8 spread; u8 jitter; u8 pierce; u16 price; u8 pw, ph;
} weapon_def_t;
enum { W_PISTOL, W_SHOTGUN, W_SMG, W_RAILGUN, W_GAUNTLET, W_COUNT };
extern const weapon_def_t g_weapons[W_COUNT];

typedef struct {
    const char *name; s16 hp; s16 speed; u8 dmg; u8 atk_range; u8 atk_cd; u8 points; u8 w, h;
    u8 ranged, flying, art, pal;
} enemy_def_t;
enum { E_GRUNT, E_RUSHER, E_THROWER, E_BAT, E_TYPES };
extern const enemy_def_t g_enemy_defs[E_TYPES];

enum { B_DMG, B_MAXHP, B_HEAL, B_SPEED, B_FIRE, B_DEFENSE, B_COINS, B_COUNT };
typedef struct { const char *name; } bonus_def_t;
extern const bonus_def_t g_bonus_defs[B_COUNT];

typedef struct { u32 dmg, speed, fire, defense, coins; } run_bonus_t;   /* multiplicateurs 8.8 cumulatifs */
extern run_bonus_t g_bonus;
typedef struct { int score, coins; } run_t;
extern run_t g_run;
void bonus_reset(void);
void bonus_apply(int id);                                /* applique + conserve (cumulatif) */

/* ============================ entites ================================ */
typedef struct {
    body_t b; s16 hp, maxhp; u8 chr, weapon, aim, aim_free, invuln, cd, anim, hurt_t, dead, dead_t;
} player_t;
extern player_t g_player;
void player_init(int chr);
void player_update(void);
void player_render(void);
void player_hurt(int dmg, int src_x_px);
void player_heal(int amount);
int  player_center_x(void);
int  player_center_y(void);
void player_set_weapon(int w);

typedef struct {
    body_t b; s16 hp, maxhp; u8 active, type, dead, dead_t, atk_cd, flash, atk_anim, anim;
    u8 bstate, btimer, bphase, wind; u16 phase16; s16 hover_y; s16 dive_x, dive_y; u8 hit_cd;
} enemy_t;
#define ENEMY_MAX 6
#define ENEMY_ALIVE_MAX 4
#define BATS_ALIVE_MAX 2
extern enemy_t g_enemies[ENEMY_MAX];
void enemies_clear(void);
int  enemies_alive(void);
int  enemies_spawn_random(void);                         /* 1 si un ennemi a ete cree */
void enemies_update(void);
void enemies_render(void);
void enemy_damage(enemy_t *e, int dmg, int kdir, int lethal);

typedef struct {
    body_t b; s16 hp, maxhp; u8 active, dead, dead_t, state, timer, melee_cd, slam_cd, flash, anim;
} boss_t;
extern boss_t g_boss;
void boss_spawn(int wave_score);
void boss_update(void);
void boss_render(void);
void boss_damage(int dmg, int lethal);

typedef struct { fx x, y, vx, vy; fx range; u8 active, w, h, friendly, pierce, lethal; u8 hitmask; s16 dmg; } proj_t;
#define PROJ_MAX 24
extern proj_t g_proj[PROJ_MAX];
void proj_clear(void);
void proj_clear_hostile(void);
proj_t *proj_alloc(void);
void proj_update(void);
void proj_render(void);
void enemy_throw(const enemy_t *e, int dir);

typedef struct { fx x, y, vy; u8 active, value, t; } coin_t;
#define COIN_MAX 10
extern coin_t g_coins[COIN_MAX];
void coins_clear(void);
void coin_spawn(int x_px, int y_px, int value);
void coins_update(void);
void coins_render(void);

typedef struct { s16 x, y; u8 life, kind; } fxp_t;
#define FXP_MAX 8
void fxp_clear(void);
void fxp_spawn(int x_px, int y_px, int life);
void fxp_update(void);
void fxp_render(void);

void weapon_fire(player_t *p);                           /* generique : toutes les armes */

/* ============================ audio / save =========================== */
enum { SFX_SHOOT, SFX_HEAVY, SFX_HIT, SFX_DEATH, SFX_COIN, SFX_JUMP, SFX_HURT, SFX_BONUS, SFX_BOSS, SFX_DOOR, SFX_COUNT };
void sfx_play(int id);

typedef struct {
    u32 magic; u16 version; u16 sum; u32 coins; u16 best_wave; u8 sel_char, equipped, owned_mask, kd_unlocked; u16 seq;
} save_t;
extern save_t g_save;
void save_load(void);
void save_write(void);

/* ============================ HUD ==================================== */
void hud_reset(void);
void hud_update(int wave, int kills, int needed, int is_boss);

/* ============================ modes ================================== */
typedef struct { void (*enter)(void); void (*update)(void); void (*render)(void); void (*leave)(void); } game_mode_t;
extern const game_mode_t MODE_TITLE, MODE_WAVES;
void game_set_mode(const game_mode_t *m);
void game_frame(void);
extern void (*g_hook_enemy_down)(void);
extern void (*g_hook_boss_down)(void);
extern void (*g_hook_player_down)(void);
/* introspection pour les tests PC */
int  waves_phase(void);
int  waves_wave(void);
int  waves_kills(void);
int  waves_needed(void);
int  waves_offer(int i);
int  waves_is_boss(void);
int  waves_lock(void);
int  waves_cursor(void);
#endif
