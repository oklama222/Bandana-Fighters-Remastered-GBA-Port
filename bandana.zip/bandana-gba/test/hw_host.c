/* Faux materiel pour tests PC : memes fonctions que hw_gba.c, memoire simulee. */
#include "hw.h"
#include <string.h>
static u16 bgt[0x2000], map[4][1024 * 4], objt[0x4000], pbg[256], pob[256], oam[512];
static u16 keys; static int sc[4][2];
static u8 sram[32768] = {0};
int hw_snd_count;
u8 *hw_host_sram(void) { return sram; }
void hw_host_sram_clear(void) { memset(sram, 0xFF, sizeof sram); }
void hw_host_set_keys(u16 k) { keys = k; }
void hw_init(void) {} void hw_vsync(void) {} void hw_flush(void) {} void hw_display(int on) { (void)on; }
u16 hw_keys(void) { return keys; }
u16 *hw_bg_tiles(void) { return bgt; }
u16 *hw_bg_map(int sb) { return map[sb - 28]; }
u16 *hw_obj_tiles(void) { return objt; }
u16 *hw_pal_bg(void) { return pbg; } u16 *hw_pal_obj(void) { return pob; } u16 *hw_oam_shadow(void) { return oam; }
void hw_set_scroll(int bg, int x, int y) { sc[bg][0] = x; sc[bg][1] = y; }
void hw_sram_read(u32 o, u8 *d, u32 n) { memcpy(d, sram + o, n); }
void hw_sram_write(u32 o, const u8 *s, u32 n) { memcpy(sram + o, s, n); }
void hw_snd_tone(u16 f, u16 e, u16 d) { (void)f; (void)e; (void)d; hw_snd_count++; }
void hw_snd_noise(u16 e, u16 c) { (void)e; (void)c; hw_snd_count++; }
