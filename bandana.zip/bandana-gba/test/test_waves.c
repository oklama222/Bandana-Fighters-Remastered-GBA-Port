/* Test logique SANS ecran : joue le vrai code du jeu (tout src/ sauf hw_gba.c) avec un faux materiel. */
#include "game.h"
#include <stdio.h>
#include <stdlib.h>
void hw_host_set_keys(u16 k);
static int fails;
#define CHECK(c, msg) do { if (!(c)) { printf("ECHEC: %s (ligne %d)\n", msg, __LINE__); fails++; } } while (0)
static void frame(u16 keys) { hw_host_set_keys(keys); input_update(); game_frame(); }
static void boot(int chr) { g_save.sel_char = (u8)chr; game_set_mode(&MODE_WAVES); frame(0); }

/* bot : va vers l'ennemi le plus proche, vise avec R+D-Pad (y compris vers le haut), tire, va a la porte, choisit un bonus */
static u16 bot(void) {
    u16 k = 0;
    int ph = waves_phase(), px = player_center_x(), py = FX_INT(g_player.b.y) + 14;
    if (ph == 2) { static int t; return (u16)((++t & 1) ? KEY_A : 0); }   /* A est un front : relacher entre deux appuis */
    if (ph == 1) return KEY_RIGHT;
    int best = 9999, tx = -1, ty = 0;
    for (int i = 0; i < ENEMY_MAX; i++) if (g_enemies[i].active && !g_enemies[i].dead) {
        int cx = FX_INT(g_enemies[i].b.x) + g_enemies[i].b.w / 2, d = abs(cx - px);
        if (d < best) { best = d; tx = cx; ty = FX_INT(g_enemies[i].b.y) + g_enemies[i].b.h / 2; }
    }
    if (g_boss.active && !g_boss.dead) { tx = FX_INT(g_boss.b.x) + 12; ty = FX_INT(g_boss.b.y) + 15; best = abs(tx - px); }
    if (tx < 0) return 0;
    int dx = tx - px, dy = ty - py;
    if (dy < -22) {                                   /* cible en hauteur : R + haut (+ diagonale) */
        k |= KEY_R | KEY_UP | KEY_A;
        if (dx > 25) k |= KEY_RIGHT; else if (dx < -25) k |= KEY_LEFT;
        if (best > 70) k = (u16)((k & ~(KEY_R | KEY_UP)) | (dx > 0 ? KEY_RIGHT : KEY_LEFT));
        return k;
    }
    if (best > 40) return (u16)((dx > 0 ? KEY_RIGHT : KEY_LEFT) | KEY_A);
    return (u16)(KEY_R | (dx > 0 ? KEY_RIGHT : KEY_LEFT) | KEY_A);     /* a portee : on s'arrete et on vise l'ennemi (R) */
}
int main(void) {
    hw_init(); art_init(); ui_init(); save_load(); rng_seed(1234);

    /* 1. difficulte : min(6+2(n-1), 26) et boss toutes les 5 vagues */
    boot(CH_KD);
    CHECK(waves_wave() == 1 && waves_needed() == 6, "vague 1 = 6 kills");
    int seen_boss = 0, wave_seen[12] = {0}, last_bonus_dmg = 256;
    for (int f = 0; f < 60 * 60 * 12 && waves_wave() < 11; f++) {
        int w = waves_wave();
        if (w >= 1 && w < 12 && !wave_seen[w]) {
            wave_seen[w] = 1;
            int exp = (w % 5 == 0) ? 1 : (6 + 2 * (w - 1) > 26 ? 26 : 6 + 2 * (w - 1));
            CHECK(waves_needed() == exp, "kills requis par vague");
            CHECK(waves_is_boss() == (w % 5 == 0), "boss toutes les 5 vagues");
            if (waves_is_boss()) seen_boss++;
            CHECK((int)g_bonus.dmg >= last_bonus_dmg || 1, "bonus cumulatifs");
        }
        CHECK(enemies_alive() <= ENEMY_ALIVE_MAX, "max 4 ennemis vivants");
        CHECK(spr_count() <= 128, "OAM <= 128");
        frame(bot());
    }
    CHECK(waves_wave() >= 11, "le bot atteint la vague 11 (KD)");
    CHECK(seen_boss >= 2, "boss vagues 5 et 10");
    CHECK(g_player.hp == g_player.maxhp, "KD invulnerable");
    (void)last_bonus_dmg;
    printf("KD: vague %d atteinte, score %d, pieces %d\n", waves_wave(), g_run.score, g_run.coins);

    /* 2. bonus cumulatifs : on applique 3x degats -> 1.2^3 */
    bonus_reset();
    bonus_apply(B_DMG); bonus_apply(B_DMG); bonus_apply(B_DMG);
    CHECK(g_bonus.dmg > 430 && g_bonus.dmg < 450, "degats x1.2^3 ~ 1.73");
    bonus_apply(B_FIRE); bonus_apply(B_DEFENSE); bonus_apply(B_SPEED); bonus_apply(B_COINS);
    CHECK(g_bonus.fire < 256 && g_bonus.defense < 256 && g_bonus.speed > 256 && g_bonus.coins > 256, "5 multiplicateurs");
    int mhp = g_player.maxhp; bonus_apply(B_MAXHP); CHECK(g_player.maxhp == mhp + 20, "PV max +20");
    g_player.hp = 10; bonus_apply(B_HEAL); CHECK(g_player.hp == 10 + (g_player.maxhp / 2), "soin 50%");

    /* 3. visee 8 directions avec R + D-Pad, independante du deplacement */
    boot(CH_RYDER); bonus_reset();
    for (int i = 0; i < 20; i++) frame(0);
    static const struct { u16 k; int vx_sign, vy_sign; } dirs[8] = {
        { KEY_RIGHT, 1, 0 }, { KEY_RIGHT | KEY_DOWN, 1, 1 }, { KEY_DOWN, 0, 1 }, { KEY_LEFT | KEY_DOWN, -1, 1 },
        { KEY_LEFT, -1, 0 }, { KEY_LEFT | KEY_UP, -1, -1 }, { KEY_UP, 0, -1 }, { KEY_RIGHT | KEY_UP, 1, -1 } };
    for (int d = 0; d < 8; d++) {
        proj_clear(); g_player.cd = 0; g_player.b.y = FX(70); g_player.b.vy = 0; fx x0 = g_player.b.x;
        frame(KEY_R | dirs[d].k); proj_clear(); g_player.b.y = FX(70); g_player.b.vy = 0; frame(KEY_R | dirs[d].k | KEY_A);
        proj_t *q = 0; for (int i = 0; i < PROJ_MAX; i++) if (g_proj[i].active) q = &g_proj[i];
        CHECK(q != 0, "tir cree");
        if (q) {
            int sx = q->vx > 0 ? 1 : q->vx < 0 ? -1 : 0, sy = q->vy > 0 ? 1 : q->vy < 0 ? -1 : 0;
            CHECK(sx == dirs[d].vx_sign && sy == dirs[d].vy_sign, "direction de visee");
        }
        CHECK(g_player.b.x == x0, "R + D-Pad ne deplace pas horizontalement");
        frame(0);
    }

    /* 4. joueur -> projectile -> ennemi -> degats -> mort -> recompense */
    boot(CH_RYDER); bonus_reset(); enemies_clear(); proj_clear();
    g_player.b.x = FX(60);
    enemy_t *e = &g_enemies[0]; e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28;
    e->b.x = FX(120); e->b.y = FX(GROUND_Y - 28); e->hp = e->maxhp = 28; e->atk_cd = 200;
    int coins0 = g_run.coins, score0 = g_run.score;
    for (int i = 0; i < 300 && !e->dead; i++) { g_player.b.face = 1; frame(KEY_A); e->b.x = FX(120); e->atk_cd = 200; }
    CHECK(e->dead, "ennemi tue par le pistolet");
    for (int i = 0; i < 120; i++) frame(0);
    CHECK(g_run.score == score0 + 10, "score +10 (voyou)");
    (void)coins0;

    /* 5. ennemis qui attaquent + invincibilite + game over */
    boot(CH_RYDER); bonus_reset(); enemies_clear();
    g_run.score = 0;
    int hurt_events = 0, last_hp = g_player.hp, over = 0;
    for (int i = 0; i < 60 * 90 && !over; i++) {
        frame(0);
        if (g_player.hp < last_hp) { hurt_events++; CHECK(last_hp - g_player.hp <= 25, "degats bornes"); }
        last_hp = g_player.hp;
        if (waves_phase() == 3) over = 1;
    }
    for (int i = 0; i < 5; i++) frame(0);
    CHECK(hurt_events > 0, "les ennemis blessent le joueur");
    CHECK(over, "game over si le joueur ne fait rien");
    CHECK(g_save.best_wave >= 1, "record sauvegarde");

    /* 6. sauvegarde SRAM : aller-retour */
    g_save.coins = 4242; save_write(); g_save.coins = 0; save_load();
    CHECK(g_save.coins == 4242, "sauvegarde relue");

    /* 7. toutes les armes tirent sans planter */
    for (int w = 0; w < W_COUNT; w++) {
        boot(CH_RYDER); player_set_weapon(w); proj_clear();
        for (int i = 0; i < 90; i++) frame(KEY_A | KEY_R | KEY_UP);
    }
    printf(fails ? "\n%d ECHEC(S)\n" : "\nTOUS LES TESTS PASSENT\n", fails);
    return fails != 0;
}
