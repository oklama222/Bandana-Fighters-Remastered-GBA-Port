/* Consolidation Mode Vagues : les 15 verifications demandees. PC/GCC uniquement (logique) - NE VALIDE PAS la ROM GBA. */
#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void hw_host_set_keys(u16 k);
u8 *hw_host_sram(void);
void hw_host_sram_clear(void);
static int fails, checks;
#define CHECK(c, msg) do { checks++; if (!(c)) { printf("  ECHEC: %s (ligne %d)\n", msg, __LINE__); fails++; } } while (0)
#define SECTION(n) printf("[%s]\n", n)
static void frame(u16 k) { hw_host_set_keys(k); input_update(); game_frame(); }
static void boot(int chr) { g_save.sel_char = (u8)chr; game_set_mode(&MODE_WAVES); frame(0); }
static void quiet(u16 k) { enemies_clear(); frame(k); }      /* micro-tests : aucun ennemi ne vient perturber */

/* ---------------- bot (KD) : avance, tire, va a la porte, choisit un bonus de facon variee ---------------- */
static int pick_downs, tog;
static u16 bot(void) {
    int ph = waves_phase(), px = player_center_x(), py = FX_INT(g_player.b.y) + 14;
    if (ph == 2) {
        if (waves_lock()) { pick_downs = rng_range(3); tog = 0; return 0; }
        if (pick_downs > 0) { tog ^= 1; if (tog) { pick_downs--; return KEY_DOWN; } return 0; }
        return KEY_A;
    }
    if (ph == 1) return KEY_RIGHT;
    int best = 9999, tx = -1, ty = 0;
    for (int i = 0; i < ENEMY_MAX; i++) if (g_enemies[i].active && !g_enemies[i].dead) {
        int cx = FX_INT(g_enemies[i].b.x) + g_enemies[i].b.w / 2, d = abs(cx - px);
        if (d < best) { best = d; tx = cx; ty = FX_INT(g_enemies[i].b.y) + g_enemies[i].b.h / 2; }
    }
    if (g_boss.active && !g_boss.dead) { tx = FX_INT(g_boss.b.x) + 12; ty = FX_INT(g_boss.b.y) + 15; best = abs(tx - px); }
    if (tx < 0) return 0;
    int dx = tx - px, dy = ty - py;
    if (dy < -22) {
        u16 k = KEY_R | KEY_UP | KEY_A;
        if (dx > 25) k |= KEY_RIGHT; else if (dx < -25) k |= KEY_LEFT;
        if (best > 70) k = (u16)((k & ~(KEY_R | KEY_UP)) | (dx > 0 ? KEY_RIGHT : KEY_LEFT));
        return k;
    }
    if (best > 40) return (u16)((dx > 0 ? KEY_RIGHT : KEY_LEFT) | KEY_A);
    return (u16)(KEY_R | (dx > 0 ? KEY_RIGHT : KEY_LEFT) | KEY_A);
}
static run_bonus_t snap_b; static int snap_max, snap_hp;
static void snap(void) { snap_b = g_bonus; snap_max = g_player.maxhp; snap_hp = g_player.hp; }
static int same_except(int id) {      /* tout est inchange sauf la categorie choisie */
    int ok = 1;
    if (id != B_DMG)     ok &= g_bonus.dmg == snap_b.dmg;
    if (id != B_SPEED)   ok &= g_bonus.speed == snap_b.speed;
    if (id != B_FIRE)    ok &= g_bonus.fire == snap_b.fire;
    if (id != B_DEFENSE) ok &= g_bonus.defense == snap_b.defense;
    if (id != B_COINS)   ok &= g_bonus.coins == snap_b.coins;
    if (id != B_MAXHP)   ok &= g_player.maxhp == snap_max;
    return ok;
}
int main(void) {
    hw_init(); art_init(); ui_init(); hw_host_sram_clear(); save_load(); rng_seed(777);

    /* ===== 1, 8, 9, 10, 13, 15 : longue partie reelle avec KD (flux complet, 16 vagues) ===== */
    SECTION("flux complet KD, vagues 1 a 16 (bonus 1, boss 8, kills 9, porte 10, KD 13, max 4 ennemis 15)");
    boot(CH_KD);
    int last_wave = 1, choices = 0, max_alive = 0, max_spr = 0, boss_seen[17] = {0}, cat_seen[B_COUNT] = {0};
    run_bonus_t prev = g_bonus; int prev_max = g_player.maxhp;
    int door_events = 0, prev_phase = 0;
    for (long f = 0; f < 60L * 60 * 60 && waves_wave() < 16; f++) {
        int w = waves_wave(), ph = waves_phase();
        if (ph == 1 && prev_phase == 0) { door_events++; CHECK(waves_kills() == waves_needed(), "kills == requis a l'ouverture de la porte"); CHECK(enemies_alive() == 0, "aucun ennemi vivant quand la porte s'ouvre"); }
        if (ph == 2 && prev_phase == 1) door_events++;
        prev_phase = ph;
        if (w != last_wave) {
            int exp = (w % 5 == 0) ? 1 : MIN(6 + 2 * (w - 1), 26);
            CHECK(waves_needed() == exp, "kills requis = min(6+2(n-1),26)");
            CHECK(waves_is_boss() == (w % 5 == 0), "boss uniquement aux vagues multiples de 5");
            CHECK(w == last_wave + 1, "les vagues avancent de 1 en 1 (pas de double passage)");
            last_wave = w;
        }
        if (waves_is_boss()) boss_seen[w] = 1;
        CHECK(!g_boss.active || waves_is_boss(), "pas de boss hors vague boss");
        CHECK(g_bonus.dmg >= prev.dmg && g_bonus.speed >= prev.speed && g_bonus.coins >= prev.coins &&
              g_bonus.fire <= prev.fire && g_bonus.defense <= prev.defense && g_player.maxhp >= prev_max, "bonus jamais perdus entre les vagues");
        prev = g_bonus; prev_max = g_player.maxhp;
        int al = enemies_alive(); if (al > max_alive) max_alive = al;
        CHECK(al <= ENEMY_ALIVE_MAX, "max 4 ennemis vivants");
        for (int i = 0; i < ENEMY_MAX; i++) if (g_enemies[i].active) {
            enemy_t *e = &g_enemies[i];
            CHECK(FX_INT(e->b.x) >= 0 && FX_INT(e->b.x) + e->b.w <= SCREEN_W, "ennemi dans l'ecran");
            CHECK(FX_INT(e->b.y) >= 0 && FX_INT(e->b.y) + e->b.h <= GROUND_Y + 1 + 4, "ennemi au-dessus du sol");
        }
        CHECK(g_player.hp == g_player.maxhp && !g_player.dead, "KD reste invulnerable");
        u16 k = bot();
        int pressing_a_in_bonus = (ph == 2 && (k & KEY_A));
        if (pressing_a_in_bonus) snap();
        int off = (ph == 2) ? waves_offer(waves_cursor()) : -1, w_before = w;
        frame(k);
        if (pressing_a_in_bonus) {
            int id = off; choices++; cat_seen[id]++;
            CHECK(waves_wave() == w_before + 1, "un seul A = une seule vague");
            switch (id) {
            case B_DMG: CHECK(g_bonus.dmg > snap_b.dmg, "bonus degats applique"); break;
            case B_SPEED: CHECK(g_bonus.speed > snap_b.speed, "bonus vitesse applique"); break;
            case B_FIRE: CHECK(g_bonus.fire < snap_b.fire, "bonus cadence applique"); break;
            case B_DEFENSE: CHECK(g_bonus.defense < snap_b.defense, "bonus defense applique"); break;
            case B_COINS: CHECK(g_bonus.coins > snap_b.coins, "bonus pieces applique"); break;
            case B_MAXHP: CHECK(g_player.maxhp == snap_max + 20 && g_player.hp == snap_hp + 20, "PV max +20 et PV +20"); break;
            case B_HEAL: CHECK(g_player.hp >= snap_hp, "soin applique"); break;
            }
            CHECK(same_except(id), "seule la categorie choisie change");
        }
        int sc = spr_count(); if (sc > max_spr) max_spr = sc;
    }
    CHECK(waves_wave() >= 16, "16 vagues atteintes");
    for (int w = 1; w <= 15; w++) if (w % 5 == 0) CHECK(boss_seen[w], "boss aux vagues 5, 10, 15");
    int ncat = 0; for (int i = 0; i < B_COUNT; i++) ncat += cat_seen[i] > 0;
    printf("  choix de bonus: %d (categories vues: %d/7), sprites max: %d, ennemis vivants max: %d, portes: %d\n", choices, ncat, max_spr, max_alive, door_events);
    CHECK(choices >= 14, "au moins 14 choix de bonus");
    CHECK(max_spr <= 128, "OAM <= 128");

    /* ===== 2, 3 : PV max et soin ===== */
    SECTION("bonus PV max et soin (2, 3)");
    boot(CH_RYDER); bonus_reset();
    g_player.hp = 50; bonus_apply(B_MAXHP);
    CHECK(g_player.maxhp == 120 && g_player.hp == 70, "PV max 100->120 et PV 50->70");
    g_player.hp = 30; bonus_apply(B_HEAL); CHECK(g_player.hp == 90, "soin 50% de 120 = +60");
    g_player.hp = 100; bonus_apply(B_HEAL); CHECK(g_player.hp == g_player.maxhp, "soin plafonne aux PV max");
    boot(CH_WALLACE); CHECK(g_player.maxhp == 130, "Wallace 130 PV"); g_player.hp = 130; bonus_apply(B_MAXHP);
    CHECK(g_player.maxhp == 150 && g_player.hp == 150, "Wallace PV max 150");
    g_player.maxhp = 121; g_player.hp = 1; bonus_apply(B_HEAL); CHECK(g_player.hp == 62, "soin arrondi (Math.round(60.5)=61)");

    /* ===== 4 : vitesse ===== */
    SECTION("bonus vitesse (4)");
    int dist[2];
    for (int t = 0; t < 2; t++) {
        boot(CH_RYDER); bonus_reset(); if (t) { bonus_apply(B_SPEED); bonus_apply(B_SPEED); bonus_apply(B_SPEED); }
        for (int i = 0; i < 5; i++) quiet(0);
        int x0 = player_center_x(); for (int i = 0; i < 30; i++) quiet(KEY_RIGHT); dist[t] = player_center_x() - x0;
    }
    printf("  distance en 30 frames: %d px -> %d px (x1.12^3 = 1.40)\n", dist[0], dist[1]);
    CHECK(dist[0] > 50 && dist[1] * 100 >= dist[0] * 135 && dist[1] * 100 <= dist[0] * 146, "vitesse x1.40 apres 3 bonus");

    /* ===== 5 : cadence ===== */
    SECTION("bonus cadence (5)");
    int shots[2];
    for (int t = 0; t < 2; t++) {
        boot(CH_RYDER); bonus_reset(); if (t) for (int i = 0; i < 4; i++) bonus_apply(B_FIRE);
        int n = 0, prevcd = 0;
        for (int i = 0; i < 240; i++) { quiet(KEY_A); if (g_player.cd > prevcd) n++; prevcd = g_player.cd; }
        shots[t] = n;
    }
    printf("  tirs en 240 frames: %d -> %d\n", shots[0], shots[1]);
    CHECK(shots[0] >= 8 && shots[0] <= 10, "pistolet ~25 frames/tir");
    CHECK(shots[1] * 100 >= shots[0] * 180, "4 bonus de cadence ~ x1.9 tirs");

    /* ===== 6 : defense ===== */
    SECTION("bonus defense (6)");
    boot(CH_RYDER); bonus_reset();
    g_player.invuln = 0; g_player.hp = 100; player_hurt(10, 0); CHECK(g_player.hp == 90, "10 degats sans bonus");
    bonus_apply(B_DEFENSE); bonus_apply(B_DEFENSE);
    g_player.invuln = 0; g_player.hp = 100; player_hurt(10, 0); CHECK(g_player.hp == 93, "10 degats avec 2 bonus = 7 (x0.72)");
    g_player.invuln = 0; g_player.hp = 100; player_hurt(1, 0); CHECK(g_player.hp == 99, "minimum 1 degat");
    for (int i = 0; i < 40; i++) { bonus_apply(B_DEFENSE); }
    CHECK(g_bonus.defense >= 64, "defense plafonnee (x0.25 mini)");

    /* ===== 7 : pieces ===== */
    SECTION("bonus pieces (7)");
    for (int t = 0; t < 2; t++) {
        boot(CH_RYDER); bonus_reset(); if (t) { bonus_apply(B_COINS); bonus_apply(B_COINS); bonus_apply(B_COINS); }
        g_save.coins = 0; g_run.coins = 0;
        coin_spawn(player_center_x(), player_center_y(), 100);
        for (int i = 0; i < 60; i++) quiet(0);
        printf("  piece de 100 -> %d en run, %d en sauvegarde RAM\n", g_run.coins, (int)g_save.coins);
        CHECK(g_run.coins == (t ? 173 : 100) && (int)g_save.coins == g_run.coins, t ? "100 x1.73 = 173" : "100 sans bonus");
    }

    SECTION("regression : saut fiable (bug 'au sol' instable corrige)");
    boot(CH_RYDER); bonus_reset(); int missed = 0;
    for (int n = 0; n < 40; n++) {
        for (int i = 0; i < 3 + (n % 5); i++) quiet(0);                  /* delais varies : toutes les phases du sol */
        int y0 = FX_INT(g_player.b.y); quiet(KEY_B); quiet(0); quiet(0);
        if (FX_INT(g_player.b.y) >= y0 - 2) missed++;
        for (int i = 0; i < 80; i++) quiet(0);
    }
    CHECK(missed == 0, "40 sauts sur 40 declenches");
    CHECK(g_player.b.ground, "au repos le joueur est bien 'au sol' a chaque frame");
    { int flick = 0; for (int i = 0; i < 40; i++) { quiet(0); if (!g_player.b.ground) flick++; } CHECK(flick == 0, "drapeau 'au sol' stable (40 frames)"); }

    /* ===== 10 : porte / bonus ne se declenche qu'une fois ===== */
    SECTION("transition combat -> porte -> bonus -> vague (10)");
    boot(CH_KD); bonus_reset();
    while (waves_kills() < waves_needed() - 1) frame(bot());
    for (int i = 0; i < ENEMY_MAX; i++) { g_enemies[i].active = 0; }
    for (int i = 0; i < 2; i++) { enemy_t *e = &g_enemies[i]; memset(e, 0, sizeof *e); e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28; e->hp = 1; e->b.x = FX(50 + i * 20); e->b.y = FX(GROUND_Y - 28); }
    int k0 = waves_kills();
    enemy_damage(&g_enemies[0], 5, 0, 0); enemy_damage(&g_enemies[1], 5, 0, 0);      /* deux morts dans la meme frame */
    CHECK(waves_phase() == 1 && waves_kills() == k0 + 1, "2 morts simultanees : une seule ouverture de porte");
    int w0 = waves_wave();
    g_player.b.x = FX(220); frame(0);
    CHECK(waves_phase() == 2, "porte atteinte -> choix de bonus");
    int o0 = waves_offer(0), o1 = waves_offer(1), o2 = waves_offer(2);
    CHECK(o0 != o1 && o1 != o2 && o0 != o2, "3 bonus distincts");
    for (int i = 0; i < 20; i++) frame(KEY_A | KEY_RIGHT);
    CHECK(waves_phase() == 2 && waves_wave() == w0 && waves_offer(0) == o0 && waves_offer(2) == o2, "verrou 0,5 s : A martele n'a rien valide, offre stable");
    for (int i = 0; i < 20; i++) frame(0);
    frame(KEY_A); for (int i = 0; i < 10; i++) frame(KEY_A);
    CHECK(waves_wave() == w0 + 1 && waves_phase() == 0, "un A maintenu = une seule vague suivante");

    SECTION("annonce des coups ennemis (equilibrage)");
    boot(CH_RYDER); bonus_reset(); enemies_clear(); g_player.b.x = FX(100); g_player.invuln = 0;
    { enemy_t *e = &g_enemies[0]; memset(e, 0, sizeof *e); e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28; e->hp = e->maxhp = 28;
      e->b.x = FX(112); e->b.y = FX(GROUND_Y - 28); e->b.face = -1; }
    int hp_a = g_player.hp, first = -1;
    for (int i = 0; i < 40; i++) { g_enemies[0].b.x = FX(112); frame(0); if (first < 0 && g_player.hp < hp_a) first = i; }
    CHECK(first >= 15 && first <= 25, "le coup arrive ~0,3 s APRES l'entree en portee (pas instantane)");
    boot(CH_RYDER); bonus_reset(); enemies_clear(); g_player.b.x = FX(100); g_player.invuln = 0;
    { enemy_t *e = &g_enemies[0]; memset(e, 0, sizeof *e); e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28; e->hp = e->maxhp = 28;
      e->b.x = FX(112); e->b.y = FX(GROUND_Y - 28); e->b.face = -1; }
    int hp_b = g_player.hp;
    frame(0); frame(0); for (int i = 0; i < 12; i++) { g_enemies[0].b.x = FX(112); frame(KEY_LEFT); }
    for (int i = 0; i < 12; i++) { g_enemies[0].b.x = FX(112); frame(0); }
    CHECK(g_player.hp == hp_b || g_player.hp > hp_b - 1, "reculer pendant l'annonce esquive le coup");

    /* ===== 11 : game over + nouvelle partie propre ===== */
    SECTION("game over et nouvelle partie (11)");
    g_save.best_wave = 50; hw_host_sram_clear();
    boot(CH_RYDER); bonus_apply(B_DMG); g_run.score = 999;
    long f = 0; while (waves_phase() != 3 && f++ < 60L * 120) frame(0);
    CHECK(waves_phase() == 3 && g_player.dead, "game over quand les PV tombent a 0");
    CHECK(g_save.best_wave == 50, "le record n'est jamais diminue");
    for (int i = 0; i < 80; i++) frame(0);
    frame(KEY_START);
    for (int i = 0; i < 3; i++) frame(0);
    frame(KEY_START); for (int i = 0; i < 3; i++) frame(0);                       /* titre -> nouvelle partie */
    CHECK(waves_wave() == 1 && !g_player.dead && g_player.hp == g_player.maxhp && g_player.maxhp == 100, "nouvelle partie : vague 1, PV pleins");
    CHECK(g_bonus.dmg == 256 && g_bonus.speed == 256 && g_bonus.fire == 256 && g_bonus.defense == 256 && g_bonus.coins == 256, "bonus remis a zero");
    CHECK(g_run.score == 0 && g_run.coins == 0 && !g_boss.active, "score/pieces/boss remis a zero");

    /* ===== 12 : sauvegarde ===== */
    SECTION("sauvegarde (12)");
    hw_host_sram_clear(); save_load();
    CHECK(g_save.coins == 0 && g_save.owned_mask == 1, "SRAM vierge (0xFF) -> valeurs par defaut");
    g_save.coins = 100; g_save.best_wave = 7; save_write();
    g_save.coins = 200; g_save.best_wave = 9; save_write();
    memset(&g_save, 0, sizeof g_save); save_load();
    CHECK(g_save.coins == 200 && g_save.best_wave == 9, "relit la sauvegarde la plus recente");
    u8 *sr = hw_host_sram(); int newest = (sr[0] == 0 && 0) ? 0 : 1;                /* derniere ecriture = slot 1 */
    sr[32 * newest + 9] ^= 0x5A;                                                      /* corrompt le slot recent */
    save_load(); CHECK(g_save.coins == 100 && g_save.best_wave == 7, "slot recent corrompu -> repli sur l'ancien (pas de perte totale)");
    g_save.coins = 300; save_write(); g_save.coins = 400; save_write();
    { save_t tmp = g_save; tmp.coins = 999; tmp.seq++; hw_sram_write(32 * 0 , (const u8 *)&tmp, 10); }   /* coupure en pleine ecriture : 10 octets seulement */
    save_load(); CHECK(g_save.coins == 400 || g_save.coins == 300, "ecriture interrompue : jamais de valeur melangee");
    CHECK(g_save.coins != 999, "donnee a moitie ecrite ignoree");
    sr[3] ^= 0xFF; sr[32 + 3] ^= 0xFF; save_load();
    CHECK(g_save.coins == 0 && g_save.best_wave == 0 && g_save.owned_mask == 1, "2 slots corrompus -> valeurs par defaut saines");
    g_save.seq = 65534; g_save.coins = 5; save_write(); g_save.coins = 6; save_write(); g_save.coins = 7; save_write();
    memset(&g_save, 0, sizeof g_save); save_load(); CHECK(g_save.coins == 7, "compteur de sequence : debordement 16 bits gere");
    g_save.coins = 999995; save_write(); boot(CH_RYDER); g_save.coins = 999995; coin_spawn(player_center_x(), player_center_y(), 100);
    for (int i = 0; i < 40; i++) quiet(0);
    CHECK(g_save.coins == 999999, "pieces plafonnees a 999999 (pas de debordement)");

    /* ===== 13 : KD ===== */
    SECTION("KD (13)");
    boot(CH_KD); g_player.invuln = 0; player_hurt(9999, 0); CHECK(g_player.hp == g_player.maxhp && !g_player.dead, "KD insensible meme a 9999 degats");
    enemies_clear(); { enemy_t *e = &g_enemies[0]; e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28; e->hp = 28; e->b.x = FX(150); e->b.y = FX(GROUND_Y - 28); e->atk_cd = 250; }
    g_player.b.x = FX(100); g_player.b.face = 1; for (int i = 0; i < 40; i++) { g_enemies[0].b.x = FX(150); frame(KEY_A); }
    CHECK(g_enemies[0].dead, "KD tue en un tir (degats letaux)");

    /* ===== 14 : armes ===== */
    SECTION("armes (14)");
    static const int first_hit[W_COUNT] = { 7, 16, 5, 20, 15 }   /* pompe : 4 plombs x 4 */;
    for (int w = 0; w < W_COUNT; w++) {
        boot(CH_RYDER); bonus_reset(); player_set_weapon(w); enemies_clear(); proj_clear();
        g_player.b.x = FX(60); g_player.b.face = 1;
        enemy_t *e = &g_enemies[0]; memset(e, 0, sizeof *e); e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28;
        e->hp = e->maxhp = 3000; e->b.x = FX(w == W_GAUNTLET ? 74 : 130); e->b.y = FX(GROUND_Y - 28);
        int hp0 = e->hp, firsthit = 0, shots_ = 0, prevcd = 0, maxproj = 0;
        for (int i = 0; i < 120; i++) {
            e->atk_cd = 250; e->b.x = FX(w == W_GAUNTLET ? 74 : 130); e->b.vx = 0; g_player.invuln = 99;
            frame(KEY_A);
            int np = 0; for (int p = 0; p < PROJ_MAX; p++) np += g_proj[p].active && g_proj[p].friendly; if (np > maxproj) maxproj = np;
            if (!firsthit && e->hp < hp0) firsthit = hp0 - e->hp;
            if (g_player.cd > prevcd) { shots_++; }
            prevcd = g_player.cd;
        }
        printf("  %-12s degats/touche=%2d tirs/120f=%2d projectiles simultanes max=%d\n", g_weapons[w].name, firsthit, shots_, maxproj);
        CHECK(firsthit == first_hit[w], "degats d'une touche conformes");
        CHECK(shots_ >= 2, "l'arme tire");
        if (w == W_SHOTGUN) CHECK(maxproj >= 4, "fusil a pompe : 4 plombs");
    }
    boot(CH_RYDER); bonus_reset(); player_set_weapon(W_RAILGUN); enemies_clear(); proj_clear(); g_player.b.x = FX(30); g_player.b.face = 1;
    for (int i = 0; i < 2; i++) { enemy_t *e = &g_enemies[i]; memset(e, 0, sizeof *e); e->active = 1; e->type = E_GRUNT; e->b.w = 12; e->b.h = 28; e->hp = e->maxhp = 500; e->b.x = FX(100 + i * 40); e->b.y = FX(GROUND_Y - 28); e->atk_cd = 250; }
    g_player.cd = 0; frame(KEY_A); for (int i = 0; i < 30; i++) { for (int j = 0; j < 2; j++) g_enemies[j].atk_cd = 250; frame(0); }
    CHECK(g_enemies[0].hp == 480 && g_enemies[1].hp == 480, "fusil perforant : 1 tir touche les 2 ennemis alignes (une fois chacun)");

    /* ===== 15 : stress du maximum d'ennemis ===== */
    SECTION("stress 4 ennemis max (15)");
    boot(CH_KD); int worst_active = 0, worst_alive = 0;
    for (int i = 0; i < 60 * 40; i++) {
        frame(KEY_LEFT);                                  /* KD n'attaque pas : les ennemis s'accumulent */
        int act = 0, al = enemies_alive(); for (int j = 0; j < ENEMY_MAX; j++) act += g_enemies[j].active;
        if (act > worst_active) worst_active = act; if (al > worst_alive) worst_alive = al;
        CHECK(al <= ENEMY_ALIVE_MAX && act <= ENEMY_MAX, "bornes du pool respectees");
        if (waves_phase() != 0) break;
    }
    printf("  actifs max: %d, vivants max: %d\n", worst_active, worst_alive);
    CHECK(worst_alive == ENEMY_ALIVE_MAX, "la limite de 4 vivants est reellement atteinte, jamais depassee");

    /* ===== visee (rappel de la logique validee) ===== */
    SECTION("visee R + D-Pad (logique validee, non modifiee)");
    boot(CH_RYDER); bonus_reset(); for (int i = 0; i < 20; i++) quiet(0);
    fx x0 = g_player.b.x; quiet(KEY_R | KEY_RIGHT); quiet(KEY_R | KEY_RIGHT);
    CHECK(g_player.b.x == x0 && g_player.aim == 0, "sol + R : Ryder s'arrete, le D-Pad vise");
    quiet(KEY_B | KEY_RIGHT); quiet(KEY_RIGHT); quiet(KEY_RIGHT);
    CHECK(!g_player.b.ground && g_player.b.vx > 0, "saut vers la droite");
    fx xa = g_player.b.x; quiet(KEY_R | KEY_LEFT); quiet(KEY_R | KEY_LEFT);
    CHECK(g_player.b.x > xa && g_player.aim == 4 && g_player.b.vx > 0, "air + R : elan conserve, visee vers la gauche");
    for (int i = 0; i < 80; i++) quiet(0);
    fx xs = g_player.b.x; for (int i = 0; i < 10; i++) quiet(KEY_LEFT); CHECK(g_player.b.x < xs && g_player.aim == 4, "sans R : D-Pad = deplacement");

    printf("\n%d verifications, %d echec(s)\n", checks, fails);
    printf(fails ? "RESULTAT : ECHEC (logique PC)\n" : "RESULTAT : logique PC OK  |  GBA/devkitARM/mGBA : NON VALIDE\n");
    return fails != 0;
}
