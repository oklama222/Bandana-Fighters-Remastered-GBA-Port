# Bandana Fighters GBA (projet separe du jeu HTML, jamais modifie)

## Compiler (necessite devkitPro : devkitARM + gbafix)
    make          -> build/BandanaFightersGBA.gba
    make run      -> lance mGBA
    make test     -> tests logiques sur PC (gcc), aucun materiel requis

## Stack : C pur + registres GBA directs (aucune bibliotheque)
Decision revisee par rapport a l'analyse : Butano n'est pas telechargeable hors-ligne ; la base reste
donc 100 % dependante de devkitARM seul. Toute la logique est separee du materiel (src/hw_gba.c) pour
etre testee sur PC (test/hw_host.c).

## Architecture
    include/  types.h hw.h game.h
    src/hw_gba.c   materiel GBA (OAM shadow, BG, input, SRAM en IWRAM, PSG)
    src/util.c camera.c level.c sprites.c   boucle/input/rng, camera unique, collisions tuiles, OAM
    src/art.c ui.c                          tuiles/palettes 4bpp (placeholders generes), texte/HUD sur BG1
    src/data.c                              persos, armes, ennemis, bonus (valeurs du jeu HTML x0.6)
    src/player.c weapons.c enemy.c boss.c proj.c   gameplay
    src/mode_title.c mode_waves.c game.c    modes (interface game_mode_t -> ajouter un mode = 1 fichier)
    test/   hw_host.c + test_waves.c        tests PC
    tools/  dump_art.c render_art.py        controle visuel des sprites

## Controles
D-Pad deplacement | B saut | A tir (maintenir) | R + D-Pad visee 8 directions | START pause | SELECT (en pause) menu

## Etat reel (voir fin de reponse) : ROM NON compilee ni lancee dans cet environnement.

## Documents
docs/STATUS.md (ce qui est valide / non valide) | docs/AUDIT.md (audit GBA) | docs/RUNGUN_DESIGN.md (conception Run & Gun) | docs/ANALYSE_PORT_GBA.md
