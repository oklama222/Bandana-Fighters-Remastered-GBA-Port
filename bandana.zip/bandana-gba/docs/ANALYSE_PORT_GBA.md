# Bandana Fighters GBA — Analyse & plan (étapes 1 à 4)

Source analysée (lecture seule) : index HTML, 7566 lignes. Le fichier original n'est pas modifié.

## 1-2. Mécaniques recensées
- Monde 400x700 (portrait) à physique en px/s : gravité 1750, vitesse 150, saut -640, PV 100, max 4 ennemis.
- 5 persos : Ryder (vitesse x1.25), Luma (saut x1.3), Jacob (dégâts x1.25), Wallace (PV x1.3, corpulent), KD (secret, invulnérable, tir létal).
- 5 armes : Pistolet, Fusil à pompe (4 plombs), Mitraillette, Fusil perforant, Gant électrique (mêlée). Boutique + pièces.
- 4 ennemis : Voyou, Fonceur, Lanceur (distance), Chauve-souris (vol, max sur écran). Boss "Le Caïd" (mêlée + onde de choc télégraphiée).
- Story : Prélude (cinématiques) + Épisode Ryder (run & gun 8000 px, mi-parcours 4000, scène Carl/labo, boss Robot géant avec allié Carl, boss Carl, objets DONNÉES/CLÉ). Épisodes Luma/Jacob/Wallace = placeholders.
- Vagues : kills = min(6+2(n-1), 26), porte, 3 bonus parmi 7 (dégâts, PV max, soin, vitesse, cadence, défense, pièces), cumulatifs, boss toutes les 5 vagues.
- Save : pièces, highScore, perso, armes, réglages, progression story, KD débloqué.
- Hors périmètre : mode en ligne (WebSocket), tactile, générateur de décor procédural en Canvas, hair/humanoid dessinés en code.

## 3. Classification
| Catégorie | Éléments |
|---|---|
| Directement transposable | Stats persos/armes/ennemis, structure vagues + bonus, logique des boss, progression, scénario du Prélude |
| À adapter | Physique (px/s -> entiers 24.8 à 60 fps), vue portrait 400x700 -> paysage 240x160, Aim Anywhere (R+D-Pad), caméra Run & Gun (1 seule caméra = scroll BG + offset OAM), max ennemis (4 -> 3-4 + 1 boss), cinématiques (boîtes de dialogue + tilemaps) |
| À remplacer | Décor procédural -> tilesets 4bpp pré-dessinés ; persos dessinés en code -> sprites 16x32/32x32 4bpp (palette par perso pour les bandanas) ; WebAudio -> Maxmod (musique) + SFX échantillonnés ; localStorage -> SRAM |
| Impossible / supprimé | Mode en ligne, particules massives, glow/blur/ombres dynamiques, 60+ sprites alpha simultanés, texte long |

Budget : 128 sprites OAM, 240x160, 32 Ko IWRAM + 256 Ko EWRAM, 96 Ko VRAM, 16 palettes de 16 couleurs par plan.
KD : 1 palette arc-en-ciel animée -> viable.

## 4. Stack choisie
**devkitARM (devkitPro) + Butano (C++20)**, avec libtonc en repli.
- Compile réellement en .gba (arm-none-eabi-gcc + gbafix), testé via mGBA.
- Butano : sprites, backgrounds, caméra, collisions, Maxmod, SRAM (32 Ko) et pipeline d'assets PNG/IT/WAV intégrés.
- Sauvegarde : SRAM 32 Ko (largement suffisant ; compatible hardware et émulateurs).
- Audio : musiques en module .it/.xm (chiptune), SFX en WAV 8 bits mono.
- Outils : Aseprite/LibreSprite pour sprites, Tiled pour niveaux, OpenMPT/Furnace pour musiques.

## Architecture
```
/src        moteur : main, game, player, enemies, boss, weapons, camera, modes (story/waves/menu), save
/include
/assets/sprites  /assets/maps  /assets/audio
/data       tables stats persos/armes/ennemis/vagues (générées à partir du jeu HTML)
/docs  /build
Makefile
```

## Plan
0. Prototype ROM (fait : src/main.c, Makefile).
1. Installer devkitPro + mGBA, `make`, vérifier le .gba.
2. Passage à Butano : sprite joueur + D-Pad + R aim, saut, caméra.
3. Armes/projectiles, ennemis, collisions, HUD.
4. Mode Vagues complet (le plus simple à valider).
5. Run & Gun Ryder + robot + Carl, Prélude.
6. Menus, boutique, SRAM, audio, optimisation.
