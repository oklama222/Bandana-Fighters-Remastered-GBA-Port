# Audit technique avant le Run & Gun   (estimations : NON MESUREES sur GBA)

## Memoire
- Tout est statique, aucune allocation dynamique (pas de malloc). Pools : 6 ennemis, 24 projectiles, 10 pieces, 8 etincelles.
- RAM utilisee (estimee) : ~4 Ko sur 32 Ko d'IWRAM (OAM shadow 1 Ko, canvas d'art 1 Ko, pools ~2 Ko). EWRAM non utilisee. Marge large.
- Pile : cv_outline() a un tampon de 1 Ko sur la pile, appele seulement a l'init (ecran force noir). OK.
- VRAM : tuiles BG ~120 sur 512 ; tuiles OBJ 312 sur 512 ; cartes de fond aux screenblocks 28-30, hors des tuiles. Pas de chevauchement.
- ROM : ~70 Ko de source -> quelques dizaines de Ko de binaire. Les vrais graphismes/musiques seront l'essentiel du poids.

## Acces VRAM / OAM / palettes
- OAM : ecrite UNIQUEMENT par hw_flush(), juste apres le debut du VBlank (copie 512 demi-mots). Jamais en dehors. OK.
- BG scroll : ecrit au meme moment que l'OAM -> camera, fond et sprites decales de la meme valeur, meme frame.
- VRAM/palettes : ecritures 16 bits uniquement (pas d'ecriture 8 bits en VRAM, qui serait corrompue sur GBA).
- RISQUE (moyen, non verifie) : le texte (ui.c) et la palette de KD sont ecrits pendant le dessin, pas dans le VBlank. Sur GBA c'est permis
  (le CPU attend) mais peut produire un artefact d'1 frame. Correctif prevu si visible : file d'attente d'ecritures videe dans hw_flush().
- Remplissage d'init (art_init/ui_init) fait en ecran force noir (DISPCNT bit 7) -> aucune contrainte de timing.

## Synchronisation et 60 FPS
- Boucle : vsync (attente active de VCOUNT) -> flush -> input -> logique -> rendu dans l'OAM shadow. 1 frame de latence constante.
- Si la logique depasse 1 frame, hw_vsync attend le VBlank suivant : jeu ralenti (30 FPS) mais jamais de dechirure d'OAM.
- Cout estime par frame (CPU 16,78 MHz = ~280 000 cycles/frame) : collisions projectiles <= 24 x 7 tests de rectangles ; 6 ennemis ; 1 boss ;
  HUD mis a jour seulement quand une valeur change. Estimation grossiere : < 15 % du budget. A MESURER avec le compteur de VCOUNT/timers.
- Divisions : ARM7TDMI n'a pas de division materielle (appel logiciel ~100 cycles). Utilisees : steer() des chauves-souris (2/frame/chauve-souris),
  rng_range (%), quelques calculs d'arme. Ordre de grandeur < 3 000 cycles/frame. Acceptable ; a remplacer par des tables si le profilage le demande.
- Attente active du vsync : fonctionne mais consomme la batterie ; remplacer par VBlankIntrWait (BIOS) plus tard (optimisation, pas un bug).

## IWRAM / EWRAM / bus cartouche
- hw_sram_read/write sont dans la section .iwram et compilees en ARM : necessaire car la SRAM est sur le meme bus que la ROM.
  RISQUE (a verifier a la compilation) : attribut target("arm") + section ".iwram" dependent du script de liaison de devkitARM.
- Code Thumb partout ailleurs (-mthumb) : plus compact, plus lent sur ROM (acces 16 bits, waitstates). Si besoin, mettre les boucles chaudes en IWRAM.
- WAITCNT (prefetch ROM) non configure : gain de vitesse gratuit a ajouter apres validation.

## Sprites
- Pire cas compte dans les tests : 18 sprites visibles en jeu ; plafond theorique 1 + 1 + 6 + 1 + 24 + 10 + 8 + 1 = 52 sur 128. Culling hors ecran actif.
- Pas de sprites affines, pas d'alpha, pas de fenetres : aucun effet lourd.

## Depassements / robustesse
- Vitesses plafonnees (chute 7 px/frame < 8 px de tuile -> pas de traversee du sol ; bonus vitesse plafonne x3 = 5,6 px/frame).
- Multiplicateurs bornes (degats/pieces x12 max, cadence/defense x0.25 min) ; calculs en u32/64 bits sans debordement (verifies par UBSan sur PC).
- Pools pleins : projectile/piece/etincelle ignores ou credites directement, jamais d'ecriture hors tableau (ASan).

## A traiter plus tard (pas bloquant)
Reperer les ecritures VRAM hors VBlank, WAITCNT, VBlankIntrWait, remplacer les divisions chaudes, mesurer la charge CPU reelle.
