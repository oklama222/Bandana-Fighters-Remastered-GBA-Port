# PRESENTATION : Run & Gun de Ryder (GBA)  -  CONCEPTION SEULEMENT, RIEN N'EST CODE
Source lue (HTML original, lecture seule) : scenes de l'Episode Ryder, `storyPlayTick`, `STORY_BOSSES`, `updateRobot`, `updateCarl`.
Echelle GBA : x0.6 (comme le Mode Vagues). 60 Hz : ms x 0.06 = frames.  Statut : voir docs/STATUS.md (GBA non valide).

## 0. Enchainement reel de l'Episode Ryder (graphe de scenes, tel que dans le HTML)
CUT(intro QG) -> LEVEL(run & gun, 8000 -> 4800 px GBA, mi-parcours a 2400) -> CUT(entree, Carl, suit Carl au labo, alarme, robot) ->
BOSS(robot geant, allie Carl) -> CUT(Carl explique les donnees) -> BOSS(Carl) -> CUT(Carl au sol, DONNEES + CLE DU QG) -> FIN.
=> Le moteur doit etre pilote par une TABLE DE SCENES en ROM (types CUT / LEVEL / BOSS / END), pas du code ecrit a la main par episode.
   Le Prelude et les 3 autres episodes reutiliseront la meme table et le meme moteur de cinematiques.

## 1. Architecture du niveau (scene LEVEL)
- Monde : 4800 px de long (600 tuiles), 160 px de haut, sol plat + quelques obstacles/plateformes. Une seule direction (droite, `dir = 1`).
- Terrain (collisions) : bitmap 1 bit/tuile en ROM (600x20 = 1,5 Ko), lu par `level_solid()` -> les collisions du Mode Vagues restent inchangees.
- Decor : segments de 32 colonnes (rues, ruelle, cloture, parking...) enchaines selon une liste en ROM ; ~19 segments, ~8 variantes.
- Fond materiel : BG0 en carte 64x32 (512 px, bouclage automatique). Quand la camera franchit une tuile, on ecrit la/les nouvelle(s)
  colonne(s) a droite (20 ecritures de 16 bits par colonne -> negligeable). Aucune copie de tout l'ecran.
- Reorganisation memoire prevue : BG0 = screenblocks 28-29, texte BG1 = 30, panneaux BG2 = 31 (utilise exactement 28 a 31).
- Entites : TOUTES en coordonnees MONDE absolues (fx). Un ennemi immobile garde la meme x monde pendant que le monde defile.

## 2. Systeme de camera : UNE SEULE CAMERA
- Une seule variable de verite : `g_cam.x` (virgule fixe). Seule `cam_update()` ecrit le scroll materiel (c'est deja le cas aujourd'hui).
- Suivi (equivalent du HTML : ligne de suivi au milieu de l'ecran, lissage) : si le joueur POUSSE vers la droite et que son centre depasse
  `cam.x + 120`, alors `cam.x += exces >> 2` (~25 %/frame, comme le dt*14 du HTML). Sinon la camera s'arrete. Elle ne recule jamais.
- Resultat voulu : Ryder reste visuellement presque fixe vers x = 120 a l'ecran, c'est le monde qui defile ; si le joueur lache la
  direction il peut se deplacer librement dans l'ecran (limite gauche = bord de camera).
- Interdit (regles anti double-scroll) :
  1. aucun tableau d'entites decale "a la main" a cause du scroll ;
  2. tout sprite passe par `spr_world(x_monde, ...)` qui soustrait `g_cam.x` UNE fois ;
  3. le scroll du fond n'est ecrit qu'a un endroit ; BG1/BG2 (HUD, dialogues) restent a 0 ;
  4. si un parallaxe est ajoute plus tard : valeur DERIVEE `cam.x >> 1` du meme `g_cam.x` (jamais une 2e camera) ; desactive au debut ;
  5. le tremblement d'ecran s'applique de la meme facon au fond et aux sprites (deja le cas).
- Tests PC prevus (automatiques) : (a) le registre de scroll == `g_cam.x` a chaque frame ; (b) une piece immobile garde sa x monde
  pendant que la camera avance et sa x ecran diminue exactement de la vitesse camera ; (c) joueur qui pousse 20 s : x ecran dans [100,140].

## 3. Systeme de progression
- Distance (pas "ennemis tues") : comme le HTML, `dist += |vx voulue|` tant que le joueur POUSSE dans la bonne direction (meme collé au mur) ;
  objectif 4800 px GBA ; barre/pourcentage dans le HUD. Aucune obligation de tuer, aucune limite de temps.
- A 50 % (2400 px) : rencontre narrative de Carl (message "silhouette familiere... c'est Carl ?!" + sprite de Carl qui traverse au loin).
  Ne declenche PAS le boss (identique au HTML).
- Apparition d'ennemis (placeholder = meme 4 types, max 4 vivants) : ils naissent juste au-dela du bord droit de la camera, de plus en plus
  souvent quand le joueur avance ; supprimes quand ils sont > 40 px derriere la camera ; pieces idem. Bats comme dans le Mode Vagues.
- Fin a 100 % : ennemis restants disparaissent, tirs ennemis effaces, joueur invulnerable, "ENTREE TROUVEE !" -> scene suivante.
- Mort en histoire : ecran d'echec -> reessayer LA SCENE COURANTE (pas tout l'episode). Pas de point de controle (le HTML n'en a pas).

## 4. Carl
- Hors combat : acteur de cinematique (T-shirt bleu), sprite humanoide supplementaire (palette propre), marche/regarde/"down".
- Mi-parcours : simple sprite decoratif non interactif.
- Boss Carl (scene BOSS, arene = 1 ecran fixe comme le Mode Vagues) : PV 300 ; vitesse 282 (fx/frame) ; melee 9 (portee 28 px, 39 f) ;
  ruee : annonce 30 f -> ruee 27 f a 1101 fx (14 degats) -> essouffle 39 f = VULNERABLE (cd 252 f, 1re ruee a 120 f, si dist > 66 px) ;
  lancer : annonce 23 f, projectile 8 degats a 730 fx (cd 192 f, si dist > 90 px) ; enrage sous 40 % PV : delais x0.7, vitesse x1.2.
- Allie Carl pendant le combat du robot : controle par l'IA. A RELIRE dans le HTML avant de coder : `spawnAlly` / `updateAlly`
  (je n'ai pas encore lu son comportement exact ; je ne l'invente pas).

## 5. Le laboratoire
- Pas un niveau a defilement : decors de CINEMATIQUE ('inside', 'lab') + ARENE FIXE 1 ecran pour les 2 boss (meme code que l'arene des vagues).
- Fonds : cartes 32x20 pre-dessinees (tuiles 4bpp), chargees a l'entree de la scene ecran noir (aucune contrainte de timing).
- Moteur de cinematiques (a ecrire AVANT le Run & Gun car le Prelude en a besoin) : boite de dialogue sur BG2/BG1, nom du locuteur colore,
  texte qui s'affiche progressivement, acteurs = sprites (ryder, luma, jacob, wallace, purple, carl, robot ; poses walk/att/hurt/ang/down),
  effets (alarme, tremblement, feu) et actions de script (flag, give DONNEES / CLE_QG, objectif).
  Limite connue : la police n'a pas d'accents -> texte en majuscules sans accents au debut ; ajouter les tuiles accentuees ensuite.

## 6. Le robot boss
- HTML : 96x160 px, PV 460, vitesse 56. GBA : un seul sprite 64x64 (hitbox ~36x56) ; sprites charges par scene (voir budget OBJ ci-dessous).
- Stats (frames/fx) : vitesse 143 ; melee 14 (portee 43 px, cd 66 f) ; coup au sol : annonce 42 f puis 20 degats (rayon 78 px, seulement si
  le joueur est au sol), cd 312 f (1er a 90 f) ; salve de 3 tirs de 8 degats a 768 fx (1 tir/16 f, annonce 23 f, cd 228 f, 1re a 150 f,
  seulement si dist > 90 px) ; enrage sous 50 % PV : vitesse x1.3, coup au sol cd x0.7, salve cd x0.65.
- Les 330 premieres frames (5,5 s) il POURSUIT CARL (allie) au lieu du joueur et n'utilise ni coup au sol ni salve : phase d'ouverture
  pour tirer sur lui sans pression. Il redevient hostile au joueur ensuite.
- Generalisation : `boss_t` devient pilote par une table de definitions (Le Caid, Robot, Carl) + une fonction d'IA par boss ;
  Le Caid du Mode Vagues doit continuer a passer les tests actuels (non-regression obligatoire).

## 7. Scrolling sur GBA - resume technique
- Une camera (fx) -> `hw_set_scroll(0, cam.x, 0)` une fois par frame dans `hw_flush()` (juste apres le debut du VBlank).
- BG0 64x32 en boucle + ecriture d'une colonne de tuiles quand `cam.x>>3` change ; les sprites sont en OAM avec x ecran = x monde - cam.x.
- Pas de scroll vertical, pas de parallaxe au debut, pas de sprites affines : cout CPU/VRAM minimal.
- Budget OBJ : 312/512 tuiles utilisees aujourd'hui ; robot 64x64 x 3 poses = 192 -> depasse. Solution : jeu de tuiles OBJ PAR SCENE
  (rechargement a l'entree, ecran noir) : arene des vagues = humanoides + chauve-souris ; Run & Gun = humanoides + Carl ; boss robot = robot + Carl.

## 8. Jalons proposes (chacun testable sur PC avant tout essai GBA)
M1 camera unique + terrain/decor en flux + tests d'invariants | M2 progression + apparition d'ennemis + HUD distance |
M3 moteur de cinematiques (Prelude jouable) | M4 boss generalises + Carl | M5 robot + allie | M6 table de scenes + drapeaux + sauvegarde (v2) | M7 art/audio.
Dependances ouvertes : relire `spawnAlly/updateAlly` ; decider du parallaxe ; accents dans la police.
