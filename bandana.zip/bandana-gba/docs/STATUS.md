# ETAT DE VALIDATION  (a garder a jour a chaque etape)

| Element | Statut |
|---|---|
| Logique du jeu (PC / gcc, sanitizers ASan+UBSan) | VALIDE : `make test` -> 81 164 verifications, 0 echec |
| Compilation devkitARM (arm-none-eabi-gcc) | NON VALIDE (jamais compile par moi ; a verifier via GitHub Actions) |
| ROM `.gba` lancee dans mGBA / VBA-M | NON VALIDE |
| Rendu reel (sprites, fonds, texte, HUD) | NON VALIDE (seuls les sprites/fond generes ont ete visualises sur PC) |
| Audio PSG | NON VALIDE |
| Sauvegarde SRAM (materiel / emulateur) | NON VALIDE (logique 2 slots validee sur PC avec une SRAM simulee) |
| Performance 60 FPS | NON MESUREE (estimations seulement, voir AUDIT.md) |

PC/GCC = logique validee.  GBA/devkitARM/mGBA = NON VALIDE.

## Ce que `make test` verifie (test/test_checks.c + test/test_waves.c)
1 bonus cumulatifs sur 16 vagues reelles | 2 PV max (+20 max ET +20 PV) | 3 soin 50 % (arrondi, plafonne)
4 vitesse x1.12^n | 5 cadence x0.85^n | 6 defense sur les degats recus (min 1) | 7 pieces sur les recompenses
8 boss aux vagues 5/10/15 | 9 kills = min(6+2(n-1),26) | 10 porte -> bonus -> vague : une seule fois
11 game over + nouvelle partie propre | 12 sauvegarde (2 slots, coupure simulee, debordements) | 13 KD invulnerable
14 5 armes (degats, plombs, perforation, cadence) | 15 max 4 ennemis vivants (atteint, jamais depasse)
+ visee R/D-Pad (logique validee, inchangee) + regression "saut fiable".

## Bugs trouves et corriges pendant cette consolidation
- SAUT : le drapeau "au sol" ne valait vrai qu'1 frame sur ~4 au repos (gravite sous-pixel) -> saut aleatoire. Sonde 1 px sous les pieds ajoutee.
- A maintenu pendant la fin de vague validait un bonus par accident -> verrou de 0,5 s a l'ouverture du choix.
- Multiplicateurs de bonus : derive d'arrondi (100 pieces x1.2^3 = 172 au lieu de 173) -> accumulateurs 16.16.
- Sauvegarde : un seul emplacement (une coupure pendant l'ecriture pouvait tout perdre) -> 2 emplacements alternes + numero de sequence + assainissement.
- Pieces : plafonnees (999 999 en sauvegarde, 4 chiffres a l'affichage).
