# ETAT DE VALIDATION  (a garder a jour a chaque etape)

| Element | Statut |
|---|---|
| Logique du jeu (PC / gcc, ASan+UBSan) | VALIDE : `make test` -> 93 420 verifications, 0 echec |
| Compilation devkitARM | VALIDE : la ROM a ete compilee par GitHub Actions (conteneur devkitpro/devkitarm) |
| ROM lancee dans un emulateur GBA | VALIDE (partiel) : lancee sur l'emulateur Android de l'utilisateur ; titre, vagues, porte, choix de bonus, game over observes sur sa video |
| Fluidite | OK selon l'utilisateur (non mesuree) |
| Son PSG | PRESENT selon l'utilisateur (qualite non evaluee) |
| Sauvegarde SRAM | FONCTIONNE en emulateur (record et pieces relus au titre) |
| Materiel GBA reel, VBA-M, autres emulateurs | NON VALIDE |
| Tir 8 directions / saut sur ROM | NON OBSERVE sur la video (a confirmer par l'utilisateur) |
| Equilibrage | EN COURS : jugee trop dure ; reglages dans include/balance.h, a re-tester a la main |

PC/GCC = logique validee.  GBA : compile et se lance en emulateur (observe par video) ; materiel reel et tests manuels detailles = NON VALIDES.

## Ce que `make test` verifie (test/test_checks.c + test/test_waves.c)
1 bonus cumulatifs sur 16 vagues reelles | 2 PV max (+20 max ET +20 PV) | 3 soin 50 % (arrondi, plafonne)
4 vitesse x1.12^n | 5 cadence x0.85^n | 6 defense sur les degats recus (min 1) | 7 pieces sur les recompenses
8 boss aux vagues 5/10/15 | 9 kills = min(6+2(n-1),26) | 10 porte -> bonus -> vague : une seule fois
11 game over + nouvelle partie propre | 12 sauvegarde (2 slots, coupure simulee, debordements) | 13 KD invulnerable
14 5 armes (degats, plombs, perforation, cadence) | 15 max 4 ennemis vivants (atteint, jamais depasse)
+ visee R/D-Pad (logique validee, inchangee) + regression "saut fiable".

## Bugs trouves et corriges pendant cette consolidation
- SAUT : le drapeau "au sol" ne valait vrai qu'1 frame sur ~4 au repos (gravite sous-pixel) -> saut aleatoire. Sonde 1 px sous les pieds ajoutee.
- A maintenu pendant la fin de vague validait un bonus par accident -> verrou de 0,5 s a l'ouverture du choix.
- Multiplicateurs de bonus : derive d'arrondi (100 pieces x1.2^3 = 172 au lieu de 173) -> accumulateurs 16.16.
- Sauvegarde : un seul emplacement (une coupure pendant l'ecriture pouvait tout perdre) -> 2 emplacements alternes + numero de sequence + assainissement.
- Pieces : plafonnees (999 999 en sauvegarde, 4 chiffres a l'affichage).

## Equilibrage (include/balance.h) - reglages de la version "difficulte 2"
Retour utilisateur : trop dur (100 -> 24 PV sur la vague 1, game over vague 2). Changements :
invincibilite 33 -> 60 frames ; annonce de 18 frames avant un coup corps a corps (reculer/sauter l'esquive ; un tir qui touche l'interrompt) ;
ennemis au sol a 85 % de vitesse ; delai d'apparition x1,25. Le bot de test (qui ne se deplace pas) progresse peu : l'effet reel se juge a la main.

## Run & Gun de Ryder : AUCUNE LIGNE DE CODE ECRITE
Etat : conception terminee, en attente de ton feu vert. Documents : CARL_RELEVE.md (releve exact du HTML), RUNGUN_ARCHITECTURE.md (camera unique,
monde, progression, scenes), RUNGUN_TESTS.md (tests anti double-scroll, specification non executee), FONT_ACCENTS.md (police).
Le Run & Gun ne sera declare termine qu'apres : compilation devkitARM + ROM produite + lancement dans un emulateur + scrolling verifie.
Documents corriges : l'ancien RUNGUN_DESIGN.md contenait des erreurs (delais des boss, rencontre de Carl a 50 %, apparition des ennemis, arene "laboratoire") ; il est remplace.
