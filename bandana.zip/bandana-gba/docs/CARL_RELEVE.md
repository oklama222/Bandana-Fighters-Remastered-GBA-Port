# RELEVE EXACT : Carl, robot, boss Carl, scenes de l'Episode Ryder
Source : HTML original, LECTURE SEULE (numeros de ligne du fichier fourni). Rien n'est devine : ce qui n'est pas dans le HTML est marque "ABSENT".
Conversions GBA : le monde HTML fait 400 px de large (GAME_W=400, ligne 1362), le monde GBA 240 px -> distances x0,6.
Vitesse px/s -> fx/frame (24.8 a 60 Hz) : x2,56. Durees ms -> frames : x0,06. (meme regle que le Mode Vagues)

## A. Carl ALLIE pendant le combat du robot  (spawnAlly l.6123, updateAlly l.6126, drawAlly l.6144)
Donnees : x=70, y=sol-66, 38x66, facing=1, lastShot=0. Apparait quand la scene 'boss' porte `ally:'carl'` (l.5539, l.5709), APRES le robot.
| Comportement (HTML) | Valeur HTML | Valeur GBA |
|---|---|---|
| Cible | le boss vivant (centre a centre) | idem |
| Il regarde | toujours vers le boss | idem |
| Trop pres (dist < 170) | RECULE a 125 px/s (dos au boss) | dist < 102 : recule 320 fx/f |
| Trop loin (dist > 290) | AVANCE a 100 px/s | dist > 174 : avance 256 fx/f |
| Entre les deux | immobile | idem |
| Tir | si 120 < dist < 320 ET 1100 ms depuis le dernier tir | 72 < dist < 192 ; 66 frames |
| Projectile | PISTOLET ami, 12x8, vx=dir*640, portee 340, **degats 4 fixes** (pas de bonus joueur) | 7x5, 1638 fx/f, 204 px, degats 4 |
| Point de tir | centre + dir*10, hauteur y+0,46*h | +6 px, meme ratio |
| Limites | x borne a [bord camera+10, bord camera+GAME_W-w-10] | [+6, 240-w-6] |
| Boss mort / absent | il ne bouge plus ni ne tire (aucune branche) | idem |
| Degats subis | AUCUN : rien ne le cible (pas d'ennemis en scene boss, projectiles et boss ne le testent pas) ; seul le coup de melee du robot declenche un CLIGNOTEMENT (`hurtUntil` 300 ms) | invulnerable, clignote 18 f |
| Interaction avec Ryder | AUCUNE (pas de collision, pas de soin, pas de dialogue en combat) | idem |
| Disparition | `storyPlayEnd` met `ally=null` ; il reste a l'ecran 1,5 s apres la mort du robot (delai de `storyPlayFinish(1500)`), puis la scene suivante (cinematique) | 90 frames puis scene suivante |
Tailles : sprite humanoide (T-shirt bleu, bandana violet `#a15bff`, peau `#c99a6b`, etiquette "CARL"). GBA : meme moteur d'humanoide 16x32 (hitbox 10x28 comme le joueur), palette propre, pas d'etiquette au debut.

## B. Boss ROBOT  (STORY_BOSSES.robot l.5990, updateRobot l.6008)
HTML : 96x160, PV 460, vitesse 56, apparait x=GAME_W-140. Maintenant (spawn) = t0 ; tous les delais ci-dessous partent de t0.
| Element | HTML | GBA |
|---|---|---|
| Poursuite de Carl | `chaseAllyUntil = t0+5500` : tant que Carl existe et t < 5500 ms, la cible est CARL | 330 frames |
| Pendant ce temps | avance vers Carl ; a portee de melee, tape Carl (CLIGNOTEMENT seulement) ; **jamais de coup au sol ni de salve** | idem |
| Apres | cible = joueur | idem |
| Vitesse | 56 ; x1,3 si PV < 50 % | 143 fx/f ; x1,3 |
| Melee | portee 72, delai 1100 ms, degats 14 (anim 380 ms) | 43 px ; 66 f ; 14 ; 23 f |
| Coup au sol | declenche si 5200 ms depuis `lastSlam` (initialise a t0+1500 -> **1er coup possible a t0+6700 ms**) ; annonce 700 ms ; frappe 150 ms ; rayon 130 ; degats 20 **seulement si le joueur est AU SOL** ; delai x0,7 enrage | 1er a 402 f ; annonce 42 f ; 9 f ; rayon 78 ; 20 ; delai 312 f (218 f enrage) |
| Salve | 3 tirs ; si 3800 ms depuis `lastVolley` (initialise t0+2500 -> **1re salve possible a t0+6300 ms**) ET dist > 150 ; 1er tir +380 ms puis toutes les 260 ms ; projectile 14x10, vx=facing*300, degats 8 ; delai x0,65 enrage | 1re a 378 f ; dist > 90 ; 23 f puis 16 f ; 8x6 ; 768 fx/f ; 8 ; delai 228 f (148 f enrage) |
| Priorite | coup au sol testé AVANT la salve | idem |
| Limites | x dans [0, GAME_W-w] | [0, 240-w] |
| Mort | `onDefeat -> storyPlayFinish(1500)` : pas de score ni de pieces ; joueur invulnerable ~4 s ; apres 1,5 s : scene suivante | idem |
GBA : sprite 64x64 (hitbox ~36x56) au lieu de 96x160 x0,6 (=58x96, trop grand pour un seul OBJ). Aucun changement de mecanique.

## C. Boss CARL  (STORY_BOSSES.carl l.5997, updateCarl l.6040)
HTML : 38x66, PV 300, vitesse 110, x=GAME_W-90. Pas d'allie. Enrage : PV < 40 % -> delais x0,7, vitesse x1,2.
| Element | HTML | GBA |
|---|---|---|
| Melee | portee 46, delai 650 ms, degats 9 | 28 px ; 39 f ; 9 |
| Ruee | si 4200 ms depuis `lastDash` (init t0+2000 -> **1re ruee a t0+6200 ms**) ET dist > 110 ; annonce 500 ms (halo bleu) ; ruee 450 ms a 430 px/s dans la direction FIXEE au depart ; **1 seul coup de 14 par ruee** (si pas invulnerable) ; fin de ruee si temps ecoule ou mur ; puis **essouffle 650 ms = vulnerable** | 1re a 372 f ; dist > 66 ; 30 f ; 27 f a 1101 fx/f ; 14 ; 39 f |
| Lancer | si 3200 ms depuis `lastThrow` (init t0+1200 -> **1er lancer a t0+4400 ms**) ET dist > 150 ; dure 380 ms, projectile a +220 ms ; 12x8, vx=facing*285, degats 8 | 1er a 264 f ; dist > 90 ; 23 f (tire a 13 f) ; 7x5 ; 730 fx/f ; 8 |
| Priorite | ruee testee AVANT le lancer | idem |
| Mort | memes regles que le robot (pas de score/pieces) | idem |

## D. Enchainement exact de l'Episode Ryder (l.5527-5552)
1. CUT d'ouverture (hors de ce releve).
2. LEVEL "PARTIE 1 - Trouver une entree" : dist 8000, midDist 4000, dir 1 (l.5528).
3. CUT : entree ('inside') -> Ryder reconnait un Purple Bandana -> "C'est Carl !" (flag met:carl) -> "Carl porte un T-shirt bleu" -> ils vont au laboratoire ('lab', Carl marche, Ryder suit) -> ALARME (alerte + tremblement) -> "Un robot geant poursuit Carl" (le robot entre par la gauche) -> Carl : "A l'aide !" -> Ryder : "Je dois aider Carl !"
4. BOSS robot, allie Carl.
5. CUT : robot detruit (flag boss:robot) -> Carl explique les donnees -> Ryder refuse de les laisser au boss.
6. BOSS Carl (sans allie).
7. CUT : Carl au sol (flag boss:carl) -> DONNEES + CLE DU QG (objets) -> Ryder part vers le QG ('hq').
8. END "FIN DE L'EPISODE RYDER" ; recompense = 100 pieces la 1re fois, puis /2 a chaque nouvelle completion (l.5667), 0 pour le Prelude.
Defaite en histoire : ecran "Retenter / Menu Histoire" ; Retenter relance LA SCENE COURANTE avec PV pleins (l.7470). Point de reprise = debut de scene, sauvegarde automatique (l.5615).

## E. Le "50 %" : CORRECTION de mon document precedent
A 4000/8000 (50 %), le HTML affiche seulement DEUX MESSAGES a l'ecran, 2,3 s d'ecart (l.5734-5738) :
"Ryder apercoit une silhouette familiere au loin..." puis "C'est... Carl ?! Il s'enfuit vers le laboratoire." + un son. **Aucun sprite de Carl, aucun combat, aucune interruption.**
La vraie rencontre (Carl suivi jusqu'au laboratoire, alarme, robot) est la CINEMATIQUE qui suit la fin du niveau a 100 %.
=> GBA : a 2400/4800 px, deux messages (bandeau de texte) + un bip. Pas de sprite Carl dans le niveau.

## F. Le laboratoire : CORRECTION
Le 'lab' n'existe que comme DECOR DE CINEMATIQUE (scene 'cut', plateau 640x360). Les combats robot/Carl utilisent le terrain et le decor URBAIN standard du jeu (arene 400 px, camera fixe) : `startGame` -> meme rendu que le solo.
=> GBA fidele : arene = celle du Mode Vagues (decor ville) ; le labo = fond de cinematique. (Option, ECART assume : un fond labo pour l'arene -> a decider par toi.)

## G. Autres corrections de mes documents precedents (erreurs trouvees en relisant)
- "Robot : coup au sol 1er a 90 f, salve 1re a 150 f" : FAUX. Les delais partent de `now+1500` / `now+2500` : 1er coup a 402 f, 1re salve a 378 f, et ni l'un ni l'autre avant 330 f (poursuite de Carl).
- "Carl : 1re ruee a 120 f" : FAUX, c'est 372 f ; 1er lancer a 264 f.
- Apparition des ennemis du Run & Gun : le HTML les fait naitre sur le BORD VISIBLE (camera+6 ou camera+GAME_W-6-w), des DEUX cotes (l.3276), pas "au-dela du bord droit".
- `enemyMinX/MaxX` : zone de vie camera-140 .. camera+GAME_W+140 (l.1423) ; nettoyage derriere : x+w < camera-160 (l.5785).
