# POLICE ET ACCENTS : analyse (rien n'est encore integre au jeu)
Mesure faite sur le HTML (40 lignes de dialogue de l'histoire, 1 325 caracteres, ligne max 79) :
- Lettres accentuees presentes : **é (32), É (19), À (4), è (4), à (3), Ç (2), ê (2), ç (1)**.
- Ponctuation presente : espace ( ) . , ! ' - et "?" dans les messages. Aucune guillemet, aucun oe-ligature, aucun emoji dans les dialogues
  (les emojis du HTML sont des icones d'objets : on les remplacera par de petites icones de tuiles, ce n'est pas du texte).

## Reponse : OUI, c'est integrable sans probleme
Police actuelle : glyphes 3x5 agrandis x2 (6x10) dans une cellule de 2 tuiles = 8x16. La cellule a 6 lignes libres : il suffit de descendre le corps du
glyphe de 2 px (lignes 2 a 11) ; les accents se dessinent a la resolution native (1 px) sur les lignes 0-1, la cedille sur les lignes 12-13.
Verification faite : rendu de test sur PC (voir /tmp, non livre) -> É È Ê À Â Ç Ù Ô Ï Ë se distinguent clairement ; aigu ≠ grave ≠ circonflexe.
Les glyphes accentues sont COMPOSES par le code (lettre de base + marque) : aucune nouvelle ligne d'art a dessiner.

## Caracteres a prevoir
- REQUIS par le HTML actuel : **É, È, À, Ç, Ê** (voir ci-dessous pourquoi pas de minuscules) + **' ? ,**
- RECOMMANDES pour mes propres textes d'interface et les episodes futurs : Â Î Ô Û Ù Ë Ï.
- Cout : ~15 glyphes x 2 tuiles = 30 tuiles BG (sur 512). Le jeu d'index de tuiles de barre doit passer de 112 a 160. Aucun impact CPU.

## Point que je signale (pas de remplacement silencieux)
La police est MAJUSCULES seulement : les dialogues du HTML sont en casse mixte. Je les afficherai EN MAJUSCULES (é -> É, à -> À, è -> È, ç -> Ç, ê -> Ê),
ce qui conserve tous les accents ET le sens. Si tu veux la casse mixte, il faut une 2e police (minuscules 3x4 + hampes) : ~30 glyphes de plus,
faisable, mais a decider. Dis-moi si tu preferes.
Les textes importants (noms, titres, objets : "EPISODE RYDER", "DONNEES", "CLE DU QG", "ENTREE TROUVEE !") garderont leurs accents : "ÉPISODE", "DONNÉES", "CLÉ", "ENTRÉE".
Dans le jeu GBA actuel (Mode Vagues), les textes d'interface n'ont PAS d'accents ("DEGATS", "PIECES") : ce sera corrige a l'integration de la police.
