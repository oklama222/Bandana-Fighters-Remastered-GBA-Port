# ARCHITECTURE FINALE DU RUN & GUN DE RYDER  -  CONCEPTION, AUCUN CODE ECRIT
Statut : conception uniquement. Le Run & Gun n'est PAS code, PAS compile, PAS teste (voir STATUS.md).
Base : docs/CARL_RELEVE.md (releve exact du HTML). Le jeu HTML n'est jamais modifie.

## 1. Regle absolue (UNE CAMERA)
`g_cam.x` est la SEULE verite du defilement. Tout le reste vit en COORDONNEES MONDE et ne change jamais a cause de la camera.
- Interdit : toute operation `x -= decalage_camera`, tout tableau d'entites translate pour "simuler" le scroll, toute 2e variable de scroll.
- Rendu : `ecran_x = monde_x - g_cam.x` (sprites, via `spr_world`, deja le cas) ; fond : registre materiel BG0HOFS = `g_cam.x & 511`.
- Seul `cam_update()` ecrit le scroll materiel. Le HUD et les dialogues (BG1/BG2) restent a 0.
- Le tremblement (`cam.sx`) s'ajoute au fond ET aux sprites avec la meme valeur (deja le cas aujourd'hui).
- Parallaxe : DESACTIVE v1. Plus tard : `bg1_scroll = g_cam.x >> 1` DERIVE de la meme variable (jamais independant).

## 2. Priorites : GAMEPLAY > CAMERA > PERFORMANCES > DECOR.

## 3. Camera (formules reprises du HTML l.5777-5788)
- Ligne de suivi : x ecran = 120 (HTML 400*0,5 -> GBA 240*0,5).
- Chaque frame : `cx_ecran = centre_joueur - cam` ; `exces = cx_ecran - 120` ; si le joueur POUSSE vers la droite (vx>0) et exces>0 :
  `cam_fx += (exces_fx * 60) >> 8` (~23 %/frame = `min(1, dt*14)` du HTML). Sinon la camera ne bouge pas. Elle ne recule jamais.
- Etat stable (Ryder 1,875 px/f) : exces ~ 8 px -> Ryder ~ x=128 a l'ecran : "quasi fixe". Relache -> la camera s'arrete, Ryder se deplace librement.
- Interne `cam_fx` (24.8) ; publie `g_cam.x = cam_fx >> 8` (entier). Le fond et les sprites lisent UNIQUEMENT `g_cam.x`.
- Limites joueur (HTML l.3579) : [cam+6, cam+240-6-w] ; ennemis : zone [cam-84, cam+240+84-w] ; nettoyage derriere : x+w < cam-96 ; pieces idem.
- Arenes (boss) : camera FIXE a 0 (`rgActive()` faux dans le HTML) ; pas de defilement.

## 4. Monde, terrain, decor
- Longueur : 4800 px de progression ; monde fini de 5200 px (650 tuiles) ; le HTML n'a PAS de plateformes dans ce niveau (sol plat) -> le terrain est "sol a y>=144, partout" (aucune carte de collision en ROM, aucune limite gauche/droite : les limites sont celles de la camera).
- Decor : fonction PURE `bg_tile(col_monde, ligne)` (skyline deterministe par graine, comme build_arena_map) -> aucune donnee en ROM, aucune derive possible.
- Fond materiel : BG0 en carte 64x32 (screenblocks 28+29), BG1 texte -> screenblock 30, BG2 panneaux -> 31 (reorganisation prevue des constantes SB_*).
- Streaming : quand `(g_cam.x>>3)` change, on ecrit la colonne monde `(g_cam.x>>3)+31` (hors ecran) dans la colonne `(col & 63)` de la carte : 20 ecritures 16 bits/colonne ; boucle si plusieurs colonnes (jamais > 1 attendue : vitesse camera < 8 px/f).
- Arene : meme BG0 (colonnes 0-29 = decor ville), camera 0.

## 5. Progression (HTML l.5753-5801, a l'identique)
- `progress_fx += |vx|` SEULEMENT si `signe(vx) == dir` (dir=+1). `vx` = vitesse VOULUE (touches), pas le deplacement reel : continue meme contre le mur/la camera.
- Relacher RIGHT -> vx=0 -> progression arretee. Aucun chrono. Aucune obligation de tuer.
- Objectif 4800 px (HTML 8000), mi-parcours 2400 (4000) ; % = progress*100/4800 affiche.
- Consequence de la visee validee (R + D-Pad) : au sol, R maintenu fige Ryder (vx=0) -> pas de progression pendant qu'on vise a l'arret ; en l'air, l'elan (vx>0) compte. Je ne change pas la regle de visee ; a toi de dire si tu veux autre chose (ex. L = verrouiller la visee sans arreter).
- 50 % : DEUX MESSAGES + bip (2,3 s d'ecart), aucun sprite, aucun boss (HTML l.5734).
- 100 % : ennemis restants meurent, tirs hostiles effaces, message "ENTREE TROUVEE !", joueur invulnerable, 1,4 s plus tard -> scene suivante.
- Apparition d'ennemis (HTML l.3872-3879, 3276) : au bord VISIBLE (cam+6 ou cam+240-6-w), 2 cotes ; delai initial 2600 ms (156 f), -35 ms (-2 f) par apparition, mini 1100 ms (66 f) ; < 4 vivants. Types = `pick_type` du Mode Vagues (chauves-souris incluses).

## 6. Table de scenes en ROM (pilote tout l'episode)
Types : CUT (dialogues + plateau), LEVEL (run & gun), BOSS (arene), END. Champs : voir CARL_RELEVE.md section D (reprise exacte de l.5527-5552).
- Etat sauvegarde (SRAM, 2 slots deja prevus) : scene courante (reprise = DEBUT de scene), drapeaux `met`, `boss`, objets DATA/CLE_QG, episodes termines, nombre de completions (recompense 100/2^n).
- Mort : ecran "RETENTER / MENU" -> `Retenter` rejoue la scene courante, PV pleins.

## 7. Boss et Carl (donnees completes : CARL_RELEVE.md)
- `boss_t` devient pilote par table (Caid, Robot, Carl) + 1 fonction d'IA chacun ; non-regression obligatoire du Caid (tests actuels).
- Carl allie = acteur IA independant du joueur (6 regles de la section A). Invulnerable. Ne tire que sur le boss.
- Budget OBJ : jeu de tuiles par scene (Run & Gun : humanoides + chauve-souris ; boss robot : robot 64x64 + Carl + Ryder ; boss Carl : Carl + Ryder). Charge a l'entree de scene (ecran noir).

## 8. Cinematiques (moteur a ecrire en premier, le Prelude en a besoin)
- Plateau HTML 640x360 (sol y=300) -> GBA 240x135 environ : x*0,375. Fonds 'house', 'inside', 'lab', 'hq' = cartes de tuiles fixes (BG0), acteurs = sprites, poses : walk / att / ang / down.
- Boite de dialogue sur BG1/BG2, nom colore, texte progressif, A = avancer, START = passer (applique quand meme objets/drapeaux, comme le HTML l.5651).
- Effets : alarme (rouge clignotant), tremblement (camera.shake), son.

## 9. Etapes de developpement (chacune testee sur PC AVANT toute ROM)
M0 tests anti-double-scroll ecrits ET passant sur un squelette de camera (RUNGUN_TESTS.md) -> M1 camera + streaming de decor + progression ->
M2 ennemis du niveau + HUD % + messages 50 %/100 % -> M3 moteur de cinematiques (Prelude) -> M4 table de scenes + sauvegarde histoire ->
M5 Carl allie + robot -> M6 boss Carl -> M7 art/audio.
Chaque jalon sera compile par GitHub Actions et lance dans un emulateur ; le Run & Gun ne sera dit "termine" qu'apres : compilation devkitARM + ROM produite + lancement emulateur + scrolling verifie.
