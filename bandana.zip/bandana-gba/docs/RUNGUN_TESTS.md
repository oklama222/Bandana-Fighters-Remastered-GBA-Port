# TESTS ANTI DOUBLE-SCROLL (ecrits AVANT le code, a rendre executables en M0)
Statut : SPECIFICATION. Aucun de ces tests n'existe encore en code ni n'a ete execute.
Principe : on ne regarde pas "ce que le jeu pretend", on relit ce que le MATERIEL recevrait : registre de scroll et entrees OAM (le faux materiel `test/hw_host.c` les expose : `hw_host_scroll(bg)`, `hw_host_oam(i)` decode x/y/tuile). Tout decalage cache apparait comme un ecart.
Notation : W(e) = coordonnee monde de l'entite ; S(e) = x ecran lu dans l'OAM ; C = g_cam.x ; H = registre BG0HOFS.

## Invariants verifies A CHAQUE FRAME dans tous les tests (si l'un casse, le test echoue)
- I1  H == (C + shake) & 511  (une seule source de scroll materiel)
- I2  pour chaque sprite d'entite visible : S(e) == W(e) - C - shake  (sprites calcules par UNE camera)
- I3  la camera ne recule jamais ; C >= 0 ; C <= monde - 240
- I4  hors scroll, aucune coordonnee monde ne change a cause de C (voir tests)

## TEST 1 - Ryder avance -> la camera avance -> les objets gardent leurs coordonnees monde
Pose : 1 piece, 1 ennemi fige (vitesse 0, IA coupee), 1 decor-marqueur a des X monde connus ; Ryder maintient RIGHT 600 frames.
Verifie : W(piece), W(ennemi), W(marqueur) sont IDENTIQUES au bit pres a chaque frame (hash des X monde constant) ; C a augmente ; I1-I3.
Detecte : tout `entite.x -= ...` lie au scroll.

## TEST 2 - Zone de suivi : Ryder reste presque fixe a l'ecran
Ryder maintient RIGHT 20 s. Apres 1 s de mise en route : S(Ryder) dans [112, 136] a CHAQUE frame ; progression augmente de |vx| par frame.
Relache RIGHT 60 f : C ne change plus, progression stable, Ryder libre de se deplacer a gauche jusqu'a cam+6.
Detecte : camera trop molle/trop vive, double suivi.

## TEST 3 - Ennemi a worldX fixe : il ne bouge a l'ecran QUE par la camera
Ennemi immobile (IA coupee) a W=900. Pour chaque frame : dS = S(t)-S(t-1) == -(C(t)-C(t-1)) EXACTEMENT (entiers).
Variantes : camera a l'arret (dS=0) ; camera qui tremble (shake) -> meme decalage pour fond et sprite.
Detecte : decalage double (dS = -2*dC) ou nul.

## TEST 4 - Projectile : trajectoire monde conservee, jamais decalee deux fois
Tir pendant que la camera avance, puis tir camera a l'arret, meme direction/arme.
Verifie : W(proj)(t) == W0 + vx*t EXACT dans les deux cas (aucun terme camera) ; S = W - C ; vitesse monde identique dans les deux cas ;
le projectile disparait selon la regle HTML (cam-30 .. cam+240+30, soit cam-18 .. cam+258 en GBA), pas selon des coordonnees ecran.
Detecte : projectile "traine" avec le fond, ou va plus vite/moins vite quand la camera bouge.

## TEST 5 - Carl et le decor utilisent exactement la meme camera
Place Carl (acteur, X monde multiple de 8) et lit dans la carte BG la colonne de tuiles de meme X monde.
Verifie : S(Carl) == (col*8) - (H & 511) en coordonnees ecran, avec le meme H que celui du fond (pas d'ecart d'1 px, meme en tremblement).
Idem pour l'allie Carl en arene (camera fixe) : S constant.
Detecte : sprite et fond sur deux scrolls differents.

## Tests supplementaires (detecteurs de double deplacement)
- T6  Interdiction statique : script qui echoue si le code du Run & Gun contient une modification d'un champ `.x` d'entite faisant intervenir `cam`/`scroll`/`g_cam` (seul `spr_world`, `cam_update`, `streaming du fond` ont le droit de lire g_cam).
- T7  Conservation : sur 10 000 frames d'entrees ALEATOIRES (graine fixee, plusieurs graines), I1-I3 + I2 sur tous les types (joueur, ennemis, projectiles, pieces, effets, porte, Carl, boss).
- T8  Fond : pour chaque frame et chaque colonne visible (C>>3 .. (C>>3)+30), l'entree de carte == `bg_tile(col_monde, ligne)` : detecte colonne manquante, decalee ou ecrite deux fois.
- T9  Pas de scroll en arene : camera a 0, H == 0 pendant tout le boss ; entites immobiles gardent le meme S.
- T10 Progression basee sur le deplacement VOULU : RIGHT tenu contre le mur -> progression avance ; relacher -> s'arrete ; horloge seule -> 0 ; R tenu au sol (vx=0) -> 0 ; RIGHT tenu en l'air -> avance.
- T11 Equivalence camera pure : rejouer la meme partie en forcant la camera a 0 et en ajoutant C a toutes les X monde de la sortie ne doit rien changer a la logique (ennemis tues, degats) : confirme que le scroll n'influence pas la logique.
- T12 Non-regression : `make test` du Mode Vagues (93 000+ verifications) reste vert.

## Instrumentation requise (a ajouter en M0, aucun effet en jeu)
`hw_host_scroll(bg,&x,&y)`, `hw_host_oam(i,&x,&y,&tile)` (lit le shadow OAM et decode les 9 bits de x), acces a la carte BG simulee (deja `hw_bg_map`).
